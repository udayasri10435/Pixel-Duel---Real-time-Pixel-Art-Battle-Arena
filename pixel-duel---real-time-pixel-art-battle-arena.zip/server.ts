import express, { Request, Response } from 'express';
import http from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import path from 'path';
import { fileURLToPath } from 'url';
import { DuelRoom, Player, PixelGrid } from './src/types/game';
import { PROMPT_LIST, getRandomPrompt } from './src/utils/prompts';
import { calculateEloChange } from './src/utils/elo';
import { PRESET_VOTING_DUELS } from './src/utils/presetDuels';
import { createEmptyGrid } from './src/utils/palettes';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const isProd = process.env.NODE_ENV === 'production';
const PORT = parseInt(process.env.PORT || '3000', 10);

const app = express();
app.use(express.json());

// In-Memory Game State
const rooms = new Map<string, DuelRoom>();
const communityVotingDuels = new Map<string, DuelRoom>();
const connectedClients = new Map<WebSocket, Player>();
const matchmakingQueue: { socket: WebSocket; player: Player }[] = [];

// Seed initial community voting duels
PRESET_VOTING_DUELS.forEach((duel) => {
  communityVotingDuels.set(duel.id, { ...duel });
});

// Seed Initial Leaderboard
const leaderboardData: Player[] = [
  {
    id: 'p-valkyrie',
    name: 'PixelValkyrie',
    avatar: '👑',
    elo: 1620,
    matchesPlayed: 74,
    wins: 48,
    losses: 22,
    draws: 4,
    currentStreak: 3,
    bestStreak: 8,
  },
  {
    id: 'p-ghost',
    name: 'GhostPainter',
    avatar: '👻',
    elo: 1780,
    matchesPlayed: 112,
    wins: 82,
    losses: 25,
    draws: 5,
    currentStreak: 5,
    bestStreak: 12,
  },
  {
    id: 'p-retromaster',
    name: 'RetroMaster_99',
    avatar: '🕹️',
    elo: 1740,
    matchesPlayed: 96,
    wins: 65,
    losses: 27,
    draws: 4,
    currentStreak: 2,
    bestStreak: 9,
  },
  {
    id: 'p-chiptune',
    name: 'ChiptuneHero',
    avatar: '🎧',
    elo: 1585,
    matchesPlayed: 62,
    wins: 38,
    losses: 21,
    draws: 3,
    currentStreak: 1,
    bestStreak: 6,
  },
  {
    id: 'p-vandals',
    name: '8BitVandals',
    avatar: '👾',
    elo: 1520,
    matchesPlayed: 88,
    wins: 54,
    losses: 30,
    draws: 4,
    currentStreak: 0,
    bestStreak: 7,
  },
  {
    id: 'p-neon',
    name: 'NeonSprite',
    avatar: '⚡',
    elo: 1490,
    matchesPlayed: 45,
    wins: 29,
    losses: 14,
    draws: 2,
    currentStreak: 2,
    bestStreak: 5,
  },
  {
    id: 'p-alchemist',
    name: 'PixelAlchemist',
    avatar: '🧪',
    elo: 1410,
    matchesPlayed: 51,
    wins: 30,
    losses: 18,
    draws: 3,
    currentStreak: 3,
    bestStreak: 6,
  },
  {
    id: 'p-starlight',
    name: 'StarlightPixel',
    avatar: '✨',
    elo: 1395,
    matchesPlayed: 32,
    wins: 19,
    losses: 12,
    draws: 1,
    currentStreak: 1,
    bestStreak: 4,
  },
  {
    id: 'p-cyberkat',
    name: 'CyberKat',
    avatar: '🐱',
    elo: 1310,
    matchesPlayed: 28,
    wins: 16,
    losses: 11,
    draws: 1,
    currentStreak: 2,
    bestStreak: 3,
  },
  {
    id: 'p-pixelrookie',
    name: 'PixelRookie',
    avatar: '🌱',
    elo: 1150,
    matchesPlayed: 14,
    wins: 6,
    losses: 7,
    draws: 1,
    currentStreak: 0,
    bestStreak: 2,
  },
];

// Helper to find or register player in leaderboard
function updatePlayerInLeaderboard(player: Player) {
  const index = leaderboardData.findIndex((p) => p.id === player.id || p.name.toLowerCase() === player.name.toLowerCase());
  if (index >= 0) {
    leaderboardData[index] = { ...leaderboardData[index], ...player };
  } else {
    leaderboardData.push({ ...player });
  }
  // Sort descending by ELO
  leaderboardData.sort((a, b) => b.elo - a.elo);
}

// REST API Endpoints
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({ status: 'ok', onlinePlayers: connectedClients.size, activeRooms: rooms.size });
});

app.get('/api/leaderboard', (_req: Request, res: Response) => {
  const sorted = [...leaderboardData].sort((a, b) => b.elo - a.elo);
  res.json(sorted);
});

app.get('/api/duels/voting', (_req: Request, res: Response) => {
  const list = Array.from(communityVotingDuels.values());
  res.json(list.reverse());
});

app.post('/api/duels/:id/vote', (req: Request, res: Response) => {
  const duelId = req.params.id;
  const { voterId, votedFor } = req.body;

  const duel = communityVotingDuels.get(duelId) || rooms.get(duelId);
  if (!duel) {
    return res.status(404).json({ error: 'Duel not found' });
  }

  if (duel.votedUserIds.includes(voterId)) {
    return res.status(400).json({ error: 'You have already voted on this duel' });
  }

  duel.votedUserIds.push(voterId);
  if (votedFor === 'player1') {
    duel.player1Votes++;
  } else {
    duel.player2Votes++;
  }

  // Broadcast vote update
  broadcastToAll({
    type: 'VOTE_UPDATE',
    duelId,
    player1Votes: duel.player1Votes,
    player2Votes: duel.player2Votes,
    totalVotes: duel.player1Votes + duel.player2Votes,
  });

  res.json({
    success: true,
    player1Votes: duel.player1Votes,
    player2Votes: duel.player2Votes,
  });
});

// HTTP & WebSocket Server Setup
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

function send(socket: WebSocket, data: unknown) {
  if (socket.readyState === WebSocket.OPEN) {
    socket.send(JSON.stringify(data));
  }
}

function broadcastToAll(data: unknown) {
  const payload = JSON.stringify(data);
  for (const client of wss.clients) {
    if (client.readyState === WebSocket.OPEN) {
      client.send(payload);
    }
  }
}

function broadcastToRoom(room: DuelRoom, data: unknown) {
  const payload = JSON.stringify(data);
  for (const [socket, player] of connectedClients.entries()) {
    if (player.id === room.player1.id || player.id === room.player2.id) {
      if (socket.readyState === WebSocket.OPEN) {
        socket.send(payload);
      }
    }
  }
}

// Bot Match Generator
function createBotDuel(humanSocket: WebSocket, humanPlayer: Player): DuelRoom {
  const promptItem = getRandomPrompt();
  const roomId = `duel-bot-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
  const gridSize = 16;

  // Pick realistic bot personality and Elo close to human player
  const botElo = Math.max(900, Math.round(humanPlayer.elo + (Math.random() * 120 - 60)));
  const botNames = ['PixelBot_9000', 'VoxelViper', 'ChibiCrafter', 'SpriteSavant', 'RetroRival'];
  const botAvatars = ['🤖', '👾', '🚀', '⭐', '🦊'];
  const botIndex = Math.floor(Math.random() * botNames.length);

  const botPlayer: Player = {
    id: `bot-${Date.now()}`,
    name: botNames[botIndex],
    avatar: botAvatars[botIndex],
    elo: botElo,
    matchesPlayed: Math.floor(Math.random() * 50) + 20,
    wins: Math.floor(Math.random() * 30) + 10,
    losses: Math.floor(Math.random() * 20) + 5,
    draws: 2,
    currentStreak: 2,
    bestStreak: 5,
  };

  const room: DuelRoom = {
    id: roomId,
    prompt: promptItem.prompt,
    category: promptItem.category,
    gridSize,
    durationSeconds: 60,
    timeRemaining: 60,
    phase: 'countdown',
    createdAt: Date.now(),
    player1: humanPlayer,
    player2: botPlayer,
    player1Grid: createEmptyGrid(gridSize),
    player2Grid: createEmptyGrid(gridSize),
    player1PixelCount: 0,
    player2PixelCount: 0,
    player1Votes: 0,
    player2Votes: 0,
    votedUserIds: [],
    isBotOpponent: true,
  };

  rooms.set(roomId, room);

  // Send MATCH_FOUND
  send(humanSocket, {
    type: 'MATCH_FOUND',
    room,
    playerRole: 'player1',
  });

  // Start 3s countdown then drawing phase
  setTimeout(() => {
    room.phase = 'drawing';
    rooms.set(roomId, room);
    send(humanSocket, { type: 'PHASE_CHANGE', phase: 'drawing', timeRemaining: room.timeRemaining });
  }, 3000);

  return room;
}

// Pair up players in matchmaking queue
function processMatchmaking() {
  while (matchmakingQueue.length >= 2) {
    const p1 = matchmakingQueue.shift()!;
    const p2 = matchmakingQueue.shift()!;

    // Make sure sockets are still open
    if (p1.socket.readyState !== WebSocket.OPEN) continue;
    if (p2.socket.readyState !== WebSocket.OPEN) {
      matchmakingQueue.unshift(p1);
      continue;
    }

    const promptItem = getRandomPrompt();
    const roomId = `duel-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const gridSize = 16;

    const room: DuelRoom = {
      id: roomId,
      prompt: promptItem.prompt,
      category: promptItem.category,
      gridSize,
      durationSeconds: 60,
      timeRemaining: 60,
      phase: 'countdown',
      createdAt: Date.now(),
      player1: p1.player,
      player2: p2.player,
      player1Grid: createEmptyGrid(gridSize),
      player2Grid: createEmptyGrid(gridSize),
      player1PixelCount: 0,
      player2PixelCount: 0,
      player1Votes: 0,
      player2Votes: 0,
      votedUserIds: [],
    };

    rooms.set(roomId, room);

    // Notify player 1
    send(p1.socket, {
      type: 'MATCH_FOUND',
      room,
      playerRole: 'player1',
    });

    // Notify player 2
    send(p2.socket, {
      type: 'MATCH_FOUND',
      room,
      playerRole: 'player2',
    });

    // 3s countdown to drawing
    setTimeout(() => {
      const active = rooms.get(roomId);
      if (active) {
        active.phase = 'drawing';
        broadcastToRoom(active, {
          type: 'PHASE_CHANGE',
          phase: 'drawing',
          timeRemaining: active.timeRemaining,
        });
      }
    }, 3000);
  }
}

// Server Game Tick (Authoritative timer for all active duels)
setInterval(() => {
  const now = Date.now();

  for (const [roomId, room] of rooms.entries()) {
    if (room.phase === 'drawing') {
      room.timeRemaining = Math.max(0, room.timeRemaining - 1);

      // If opponent is a bot, simulate realistic bot drawing progress
      if (room.isBotOpponent && room.timeRemaining % 2 === 0) {
        // Add random bot pixel strokes
        const r = Math.floor(Math.random() * room.gridSize);
        const c = Math.floor(Math.random() * room.gridSize);
        const botPalette = ['#f43f5e', '#06b6d4', '#eab308', '#a855f7', '#ffffff', '#18181b'];
        const randomColor = botPalette[Math.floor(Math.random() * botPalette.length)];
        room.player2Grid[r][c] = randomColor;
        room.player2PixelCount = Math.min(room.gridSize * room.gridSize, room.player2PixelCount + 1);

        broadcastToRoom(room, {
          type: 'OPPONENT_UPDATE',
          playerRole: 'player2',
          pixelCount: room.player2PixelCount,
          lastCoord: { r, c },
        });
      }

      broadcastToRoom(room, {
        type: 'TIMER_TICK',
        timeRemaining: room.timeRemaining,
      });

      // Drawing time is up! Transition to Voting
      if (room.timeRemaining <= 0) {
        room.phase = 'voting';
        // Add to community voting pool for all spectators and users
        communityVotingDuels.set(room.id, { ...room });

        broadcastToRoom(room, {
          type: 'PHASE_CHANGE',
          phase: 'voting',
          room,
        });

        // Broadcast new voting duel available to everyone
        broadcastToAll({
          type: 'NEW_COMMUNITY_DUEL',
          duel: room,
        });
      }
    }
  }
}, 1000);

// WebSocket Connection Handler
wss.on('connection', (socket: WebSocket) => {
  let currentPlayer: Player | null = null;

  socket.on('message', (message: string) => {
    try {
      const data = JSON.parse(message.toString());

      switch (data.type) {
        // Handshake & Player Profile
        case 'AUTH': {
          currentPlayer = {
            id: data.player.id || `p-${Date.now()}`,
            name: data.player.name || 'PixelArtist',
            avatar: data.player.avatar || '🎨',
            elo: data.player.elo || 1200,
            matchesPlayed: data.player.matchesPlayed || 0,
            wins: data.player.wins || 0,
            losses: data.player.losses || 0,
            draws: data.player.draws || 0,
            currentStreak: data.player.currentStreak || 0,
            bestStreak: data.player.bestStreak || 0,
          };
          connectedClients.set(socket, currentPlayer);
          updatePlayerInLeaderboard(currentPlayer);

          send(socket, {
            type: 'AUTH_SUCCESS',
            player: currentPlayer,
            onlineCount: connectedClients.size,
          });

          // Send current active voting duels
          send(socket, {
            type: 'COMMUNITY_DUELS_SYNC',
            duels: Array.from(communityVotingDuels.values()),
          });
          break;
        }

        // Join Matchmaking Queue
        case 'QUEUE_JOIN': {
          if (!currentPlayer) return;

          // Remove if already in queue
          const existingIdx = matchmakingQueue.findIndex((q) => q.socket === socket);
          if (existingIdx >= 0) matchmakingQueue.splice(existingIdx, 1);

          matchmakingQueue.push({ socket, player: currentPlayer });

          send(socket, {
            type: 'QUEUE_STATUS',
            inQueue: true,
            queuePosition: matchmakingQueue.length,
          });

          // Try pairing immediately
          processMatchmaking();
          break;
        }

        // Leave Matchmaking Queue
        case 'QUEUE_LEAVE': {
          const idx = matchmakingQueue.findIndex((q) => q.socket === socket);
          if (idx >= 0) {
            matchmakingQueue.splice(idx, 1);
          }
          send(socket, {
            type: 'QUEUE_STATUS',
            inQueue: false,
          });
          break;
        }

        // Start vs Bot immediately
        case 'START_BOT_DUEL': {
          if (!currentPlayer) return;
          createBotDuel(socket, currentPlayer);
          break;
        }

        // Real-time Pixel update during duel
        case 'CANVAS_UPDATE': {
          const { roomId, playerRole, grid, pixelCount } = data;
          const room = rooms.get(roomId);
          if (!room || room.phase !== 'drawing') return;

          if (playerRole === 'player1') {
            room.player1Grid = grid;
            room.player1PixelCount = pixelCount;
          } else {
            room.player2Grid = grid;
            room.player2PixelCount = pixelCount;
          }

          // Broadcast progress info to opponent
          broadcastToRoom(room, {
            type: 'OPPONENT_UPDATE',
            playerRole,
            pixelCount,
          });
          break;
        }

        // Cast Vote on a Duel
        case 'CAST_VOTE': {
          const { duelId, voterId, votedFor } = data;
          const duel = communityVotingDuels.get(duelId) || rooms.get(duelId);
          if (!duel) return;

          if (duel.votedUserIds.includes(voterId)) {
            send(socket, { type: 'VOTE_ERROR', message: 'Already voted!' });
            return;
          }

          duel.votedUserIds.push(voterId);
          if (votedFor === 'player1') {
            duel.player1Votes++;
          } else {
            duel.player2Votes++;
          }

          // Calculate current Elo forecast
          const score1 = duel.player1Votes > duel.player2Votes ? 1 : duel.player1Votes === duel.player2Votes ? 0.5 : 0;
          const eloResult = calculateEloChange(duel.player1.elo, duel.player2.elo, score1);
          duel.player1EloChange = eloResult.changeA;
          duel.player2EloChange = eloResult.changeB;

          broadcastToAll({
            type: 'VOTE_UPDATE',
            duelId,
            player1Votes: duel.player1Votes,
            player2Votes: duel.player2Votes,
            totalVotes: duel.player1Votes + duel.player2Votes,
            player1EloChange: duel.player1EloChange,
            player2EloChange: duel.player2EloChange,
          });
          break;
        }

        // Finalize / Conclude Duel Results
        case 'CONCLUDE_DUEL': {
          const { duelId } = data;
          const duel = communityVotingDuels.get(duelId) || rooms.get(duelId);
          if (!duel || duel.phase === 'finished') return;

          duel.phase = 'finished';
          let score1 = 0.5;
          if (duel.player1Votes > duel.player2Votes) {
            duel.winnerId = duel.player1.id;
            score1 = 1;
          } else if (duel.player2Votes > duel.player1Votes) {
            duel.winnerId = duel.player2.id;
            score1 = 0;
          } else {
            duel.winnerId = 'draw';
            score1 = 0.5;
          }

          const eloResult = calculateEloChange(duel.player1.elo, duel.player2.elo, score1);
          duel.player1EloChange = eloResult.changeA;
          duel.player2EloChange = eloResult.changeB;

          // Update player 1 stats
          duel.player1.elo = eloResult.newRatingA;
          duel.player1.matchesPlayed++;
          if (score1 === 1) {
            duel.player1.wins++;
            duel.player1.currentStreak++;
            duel.player1.bestStreak = Math.max(duel.player1.bestStreak, duel.player1.currentStreak);
          } else if (score1 === 0) {
            duel.player1.losses++;
            duel.player1.currentStreak = 0;
          } else {
            duel.player1.draws++;
          }
          updatePlayerInLeaderboard(duel.player1);

          // Update player 2 stats
          duel.player2.elo = eloResult.newRatingB;
          duel.player2.matchesPlayed++;
          if (score1 === 0) {
            duel.player2.wins++;
            duel.player2.currentStreak++;
            duel.player2.bestStreak = Math.max(duel.player2.bestStreak, duel.player2.currentStreak);
          } else if (score1 === 1) {
            duel.player2.losses++;
            duel.player2.currentStreak = 0;
          } else {
            duel.player2.draws++;
          }
          updatePlayerInLeaderboard(duel.player2);

          broadcastToAll({
            type: 'DUEL_FINALIZED',
            duel,
          });
          break;
        }

        // Quick Taunt / Chat in Match
        case 'SEND_TAUNT': {
          const { roomId, text } = data;
          const room = rooms.get(roomId);
          if (!room || !currentPlayer) return;

          broadcastToRoom(room, {
            type: 'TAUNT_RECEIVED',
            senderName: currentPlayer.name,
            senderId: currentPlayer.id,
            text,
          });
          break;
        }
      }
    } catch (err) {
      console.error('Error handling WebSocket message:', err);
    }
  });

  socket.on('close', () => {
    // Remove from queue
    const qIdx = matchmakingQueue.findIndex((q) => q.socket === socket);
    if (qIdx >= 0) matchmakingQueue.splice(qIdx, 1);

    connectedClients.delete(socket);
  });
});

// Dev Vite Middlewares or Production Static
if (!isProd) {
  const { createServer: createViteServer } = await import('vite');
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: 'spa',
  });
  app.use(vite.middlewares);
} else {
  app.use(express.static(path.resolve(__dirname, 'dist')));
  app.get('*', (_req: Request, res: Response) => {
    res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
  });
}

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Pixel Duel server running on port ${PORT}`);
});
