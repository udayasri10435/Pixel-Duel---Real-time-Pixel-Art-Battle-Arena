import React, { useState, useEffect } from 'react';
import { DuelRoom, PixelGrid, Player } from '../types/game';
import { PixelCanvas } from './PixelCanvas';
import { getEloTier } from '../utils/elo';
import { countDrawnPixels } from '../utils/palettes';
import { sound } from '../utils/audio';
import { 
  Timer, 
  Flame, 
  Swords, 
  Sparkles, 
  MessageSquare, 
  Eye, 
  EyeOff, 
  Send,
  Trophy,
  CheckCircle2
} from 'lucide-react';

interface DuelArenaProps {
  room: DuelRoom;
  playerRole: 'player1' | 'player2';
  onGridChange: (grid: PixelGrid) => void;
  onSendTaunt: (text: string) => void;
  incomingTaunts: { senderName: string; text: string; id: string }[];
  onFinishDrawing?: () => void;
  onGoToVoting: (duelId: string) => void;
}

export const DuelArena: React.FC<DuelArenaProps> = ({
  room,
  playerRole,
  onGridChange,
  onSendTaunt,
  incomingTaunts,
  onGoToVoting,
}) => {
  const isPlayer1 = playerRole === 'player1';
  const myPlayer = isPlayer1 ? room.player1 : room.player2;
  const opponent = isPlayer1 ? room.player2 : room.player1;
  const myGrid = isPlayer1 ? room.player1Grid : room.player2Grid;
  const opponentGrid = isPlayer1 ? room.player2Grid : room.player1Grid;
  const myPixelCount = countDrawnPixels(myGrid);
  const opponentPixelCount = isPlayer1 ? room.player2PixelCount : room.player1PixelCount;

  const [showFogOfWar, setShowFogOfWar] = useState<boolean>(true);
  const [countdownNum, setCountdownNum] = useState<number>(3);
  const [customTaunt, setCustomTaunt] = useState<string>('');

  const myTier = getEloTier(myPlayer.elo);
  const opponentTier = getEloTier(opponent.elo);

  // Beep on countdown or urgency timer
  useEffect(() => {
    if (room.phase === 'countdown') {
      sound.playCountdown(false);
      const timer = setInterval(() => {
        setCountdownNum((prev) => {
          if (prev <= 1) {
            sound.playMatchStart();
            clearInterval(timer);
            return 0;
          }
          sound.playCountdown(false);
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [room.phase]);

  // Audio alert on last 10 seconds
  useEffect(() => {
    if (room.phase === 'drawing' && room.timeRemaining <= 10 && room.timeRemaining > 0) {
      sound.playCountdown(room.timeRemaining <= 3);
    }
  }, [room.timeRemaining, room.phase]);

  const quickTaunts = [
    'GG!', 
    'Nice pixels! 🎨', 
    'Hurry up! ⏰', 
    'Masterpiece! ✨', 
    'Pixel Fire! 🔥', 
    'Check this out! 👾'
  ];

  const handleSendTaunt = (text: string) => {
    if (!text.trim()) return;
    onSendTaunt(text.trim());
    sound.playClick();
    setCustomTaunt('');
  };

  const timerColor = 
    room.timeRemaining <= 10 
      ? 'text-rose-500 animate-pulse' 
      : room.timeRemaining <= 25 
      ? 'text-amber-400' 
      : 'text-emerald-400';

  return (
    <div className="relative max-w-7xl mx-auto px-2 sm:px-4 py-3 space-y-4">
      {/* 3, 2, 1 Countdown Fullscreen Overlay */}
      {room.phase === 'countdown' && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex flex-col items-center justify-center text-center p-4">
          <div className="text-xl sm:text-2xl font-mono text-cyan-400 uppercase tracking-widest mb-4">
            Duel Starting in...
          </div>
          <div className="font-pixel text-7xl sm:text-9xl font-bold bg-gradient-to-b from-rose-400 via-pink-500 to-indigo-500 bg-clip-text text-transparent animate-bounce">
            {countdownNum > 0 ? countdownNum : 'DUEL!'}
          </div>
          <div className="mt-8 max-w-md p-4 bg-slate-900 border border-slate-800 rounded-xl shadow-2xl">
            <span className="text-xs uppercase font-mono text-slate-400">Target Prompt</span>
            <h2 className="text-lg sm:text-xl font-bold text-white mt-1">"{room.prompt}"</h2>
          </div>
        </div>
      )}

      {/* Duel Banner: Header with Prompt & Clock */}
      <div className="relative p-4 sm:p-5 bg-gradient-to-r from-slate-900 via-slate-900/90 to-slate-900 border-2 border-slate-800 rounded-2xl shadow-xl overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-rose-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="relative flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Prompt Information */}
          <div className="flex items-center gap-3 text-center md:text-left">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-rose-500 to-amber-500 flex items-center justify-center shadow-lg shadow-rose-500/20 flex-shrink-0">
              <Swords className="w-6 h-6 text-white" />
            </div>

            <div>
              <div className="flex items-center gap-2 justify-center md:justify-start">
                <span className="text-xs font-mono text-slate-400 uppercase tracking-wider">
                  Target Theme
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-950 text-cyan-400 border border-cyan-800/60">
                  {room.category}
                </span>
              </div>
              <h1 className="text-xl sm:text-2xl font-bold text-white mt-0.5 tracking-wide">
                "{room.prompt}"
              </h1>
            </div>
          </div>

          {/* Authoritative Clock */}
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3 px-5 py-2.5 bg-slate-950/90 border border-slate-800 rounded-xl shadow-inner">
              <Timer className={`w-6 h-6 ${timerColor}`} />
              <div className="flex flex-col items-center">
                <span className="text-[10px] uppercase font-mono text-slate-400">Time Left</span>
                <span className={`font-pixel text-2xl sm:text-3xl ${timerColor}`}>
                  {room.timeRemaining}s
                </span>
              </div>
            </div>

            {/* Duel Status Pill */}
            <div className="hidden sm:flex flex-col items-end">
              <span className="text-[11px] font-mono text-slate-400">Phase</span>
              <span className="text-xs font-bold text-rose-400 uppercase tracking-wider flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                Live Draw
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Floating Incoming Taunts */}
      {incomingTaunts.length > 0 && (
        <div className="fixed bottom-6 right-6 z-40 flex flex-col gap-2 pointer-events-none">
          {incomingTaunts.slice(-3).map((t) => (
            <div 
              key={t.id}
              className="px-3 py-2 bg-slate-900/95 border-2 border-cyan-500/80 rounded-xl text-white text-xs font-mono shadow-2xl animate-bounce flex items-center gap-2"
            >
              <MessageSquare className="w-3.5 h-3.5 text-cyan-400" />
              <span><strong>{t.senderName}:</strong> {t.text}</span>
            </div>
          ))}
        </div>
      )}

      {/* Battle Workspace: Split 2-Column Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Left Column (8 cols): My Interactive Canvas */}
        <div className="lg:col-span-8 space-y-3">
          {/* Player Header */}
          <div className="flex items-center justify-between p-3 bg-slate-900/80 border border-slate-800 rounded-xl">
            <div className="flex items-center gap-2.5">
              <span className="text-2xl">{myPlayer.avatar}</span>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-white text-sm">{myPlayer.name}</span>
                  <span className="text-xs font-mono px-1.5 py-0.5 rounded bg-slate-800 text-rose-400 border border-slate-700">
                    YOU
                  </span>
                  <span title={myTier.title}>{myTier.badge}</span>
                </div>
                <div className="text-xs font-mono text-slate-400">
                  Rating: <span className="text-amber-400 font-semibold">{myPlayer.elo}</span> ELO
                </div>
              </div>
            </div>

            {/* Pixel Counter Progress */}
            <div className="text-right">
              <span className="text-xs font-mono text-slate-400">Filled Pixels</span>
              <div className="font-pixel text-base text-rose-400">
                {myPixelCount} <span className="text-xs text-slate-500">/ {room.gridSize * room.gridSize}</span>
              </div>
            </div>
          </div>

          {/* Interactive Canvas */}
          <PixelCanvas
            grid={myGrid}
            onChange={onGridChange}
            size={room.gridSize}
            readOnly={room.phase !== 'drawing'}
            showControls={true}
          />
        </div>

        {/* Right Column (4 cols): Opponent Podium & Live Duel Radar */}
        <div className="lg:col-span-4 space-y-4">
          {/* Opponent Identity Card */}
          <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <span className="text-2xl">{opponent.avatar}</span>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-white text-sm">{opponent.name}</span>
                    <span title={opponentTier.title}>{opponentTier.badge}</span>
                  </div>
                  <div className="text-xs font-mono text-slate-400">
                    Rating: <span className="text-cyan-400 font-semibold">{opponent.elo}</span> ELO
                  </div>
                </div>
              </div>

              {/* Bot or Live Indicator */}
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800">
                {room.isBotOpponent ? 'DUEL BOT' : 'LIVE 1V1'}
              </span>
            </div>

            {/* Live Pixel Comparison Bar */}
            <div>
              <div className="flex justify-between text-xs font-mono text-slate-400 mb-1">
                <span className="text-rose-400">You ({myPixelCount})</span>
                <span className="text-cyan-400">Rival ({opponentPixelCount})</span>
              </div>
              <div className="w-full h-3 bg-slate-950 rounded-full overflow-hidden flex border border-slate-800">
                <div 
                  className="bg-rose-500 transition-all duration-300"
                  style={{ 
                    width: `${
                      myPixelCount + opponentPixelCount > 0 
                        ? (myPixelCount / (myPixelCount + opponentPixelCount)) * 100 
                        : 50
                    }%` 
                  }}
                />
                <div 
                  className="bg-cyan-500 transition-all duration-300"
                  style={{ 
                    width: `${
                      myPixelCount + opponentPixelCount > 0 
                        ? (opponentPixelCount / (myPixelCount + opponentPixelCount)) * 100 
                        : 50
                    }%` 
                  }}
                />
              </div>
            </div>

            {/* Fog-of-War Radar Canvas */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-slate-400 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                  Rival Radar
                </span>
                <button
                  type="button"
                  onClick={() => setShowFogOfWar(!showFogOfWar)}
                  className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-white cursor-pointer"
                >
                  {showFogOfWar ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                  <span>{showFogOfWar ? 'Fog Active' : 'Reveal'}</span>
                </button>
              </div>

              {/* Opponent Preview Canvas */}
              <div className="relative aspect-square max-w-[200px] mx-auto p-2 bg-slate-950 border border-slate-800 rounded-lg overflow-hidden flex items-center justify-center">
                <div
                  className={`grid aspect-square w-full rounded overflow-hidden transition-all ${
                    showFogOfWar ? 'filter blur-[3px] opacity-75' : ''
                  }`}
                  style={{
                    gridTemplateColumns: `repeat(${room.gridSize}, minmax(0, 1fr))`,
                  }}
                >
                  {opponentGrid.map((row, r) =>
                    row.map((cell, c) => (
                      <div
                        key={`opp-${r}-${c}`}
                        style={{
                          backgroundColor: cell && cell !== 'transparent' ? (showFogOfWar ? '#22d3ee' : cell) : '#090d16',
                        }}
                        className="w-full h-full"
                      />
                    ))
                  )}
                </div>

                {showFogOfWar && (
                  <div className="absolute inset-0 bg-slate-950/40 backdrop-blur-[2px] flex flex-col items-center justify-center p-2 text-center">
                    <span className="text-[10px] font-pixel text-cyan-300">
                      DRAWING IN PROGRESS
                    </span>
                    <span className="text-[9px] font-mono text-slate-400 mt-1">
                      Full reveal during community voting!
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Quick Taunts & Emojis */}
          <div className="p-3.5 bg-slate-900/90 border border-slate-800 rounded-xl space-y-2">
            <span className="text-xs font-mono text-slate-400 flex items-center gap-1.5">
              <MessageSquare className="w-3.5 h-3.5 text-rose-400" />
              Quick Taunt / Chat
            </span>

            <div className="grid grid-cols-2 gap-1.5">
              {quickTaunts.map((taunt) => (
                <button
                  key={taunt}
                  type="button"
                  onClick={() => handleSendTaunt(taunt)}
                  className="px-2 py-1.5 text-xs bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg border border-slate-700/60 transition-colors text-left truncate cursor-pointer"
                >
                  {taunt}
                </button>
              ))}
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendTaunt(customTaunt);
              }}
              className="flex gap-1 mt-2"
            >
              <input
                type="text"
                maxLength={40}
                placeholder="Send quick taunt..."
                value={customTaunt}
                onChange={(e) => setCustomTaunt(e.target.value)}
                className="flex-1 bg-slate-950 border border-slate-800 text-xs rounded-lg px-2.5 py-1 text-slate-200 placeholder-slate-500 outline-none focus:border-rose-500"
              />
              <button
                type="submit"
                className="px-2.5 py-1 bg-rose-500 hover:bg-rose-600 text-white rounded-lg text-xs cursor-pointer"
              >
                <Send className="w-3 h-3" />
              </button>
            </form>
          </div>

          {/* Transition Button if Finished or Time Expired */}
          {room.phase === 'voting' && (
            <div className="p-4 bg-gradient-to-r from-emerald-950/40 to-cyan-950/40 border-2 border-emerald-500/50 rounded-xl text-center space-y-2 animate-bounce">
              <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
              <h3 className="font-pixel text-sm text-emerald-300">TIME IS UP!</h3>
              <p className="text-xs font-mono text-slate-300">
                Your masterpieces have entered the Community Voting Arena!
              </p>
              <button
                type="button"
                onClick={() => onGoToVoting(room.id)}
                className="w-full mt-2 py-2 px-4 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-bold text-xs uppercase tracking-wider rounded-lg shadow-lg cursor-pointer"
              >
                View Voting Arena & Tally →
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
