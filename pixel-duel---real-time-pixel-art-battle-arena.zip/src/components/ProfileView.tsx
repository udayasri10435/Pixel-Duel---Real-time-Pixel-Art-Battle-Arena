import React, { useState } from 'react';
import { Player, HistoricalMatch } from '../types/game';
import { getEloTier, getTierProgress } from '../utils/elo';
import { exportGridToDataUrl } from '../utils/palettes';
import { sound } from '../utils/audio';
import { 
  User, 
  Trophy, 
  Flame, 
  Download, 
  Sparkles, 
  Edit3, 
  Check, 
  History,
  TrendingUp,
  Percent,
  Swords
} from 'lucide-react';

interface ProfileViewProps {
  player: Player;
  onUpdatePlayer: (updated: Partial<Player>) => void;
  matches: HistoricalMatch[];
  onStartDuel: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  player,
  onUpdatePlayer,
  matches,
  onStartDuel,
}) => {
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [nameInput, setNameInput] = useState<string>(player.name);
  const [selectedAvatar, setSelectedAvatar] = useState<string>(player.avatar);

  const tier = getEloTier(player.elo);
  const progress = getTierProgress(player.elo);

  const avatarOptions = ['🎨', '👾', '👑', '⚡', '👻', '🕹️', '🎧', '🐱', '🦊', '🚀', '🔥', '🧪'];

  const handleSaveProfile = () => {
    if (!nameInput.trim()) return;
    onUpdatePlayer({
      name: nameInput.trim(),
      avatar: selectedAvatar,
    });
    setIsEditing(false);
    sound.playClick();
  };

  const handleDownloadMatchArt = (match: HistoricalMatch) => {
    const url = exportGridToDataUrl(match.myGrid, 24);
    if (!url) return;
    const a = document.createElement('a');
    a.href = url;
    a.download = `pixel-duel-${match.prompt.toLowerCase().replace(/\s+/g, '-')}.png`;
    a.click();
    sound.playVictory();
  };

  const totalMatches = player.wins + player.losses + player.draws;
  const winRate = totalMatches > 0 ? Math.round((player.wins / totalMatches) * 100) : 0;

  return (
    <div className="max-w-6xl mx-auto px-2 sm:px-4 py-4 space-y-6">
      {/* Profile Card & ELO Tier Progression */}
      <div className="p-6 bg-gradient-to-r from-slate-900 via-slate-900/90 to-slate-900 border-2 border-slate-800 rounded-2xl shadow-xl space-y-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Identity Info */}
          <div className="flex items-center gap-4">
            <div className="relative group">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-rose-500 via-pink-600 to-indigo-600 flex items-center justify-center text-4xl shadow-xl shadow-rose-500/20 border-2 border-white/20">
                {player.avatar}
              </div>
            </div>

            <div className="space-y-1">
              {isEditing ? (
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    maxLength={18}
                    value={nameInput}
                    onChange={(e) => setNameInput(e.target.value)}
                    className="bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1 text-sm font-bold text-white outline-none focus:border-rose-500"
                  />
                  <button
                    type="button"
                    onClick={handleSaveProfile}
                    className="p-1.5 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg cursor-pointer"
                  >
                    <Check className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <h1 className="text-2xl font-bold text-white">{player.name}</h1>
                  <button
                    type="button"
                    onClick={() => setIsEditing(true)}
                    className="p-1 text-slate-400 hover:text-white cursor-pointer"
                    title="Edit Name & Avatar"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                </div>
              )}

              <div className="flex items-center gap-2">
                <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-mono font-bold border ${tier.borderClass} ${tier.bgClass}`}>
                  <span>{tier.badge}</span>
                  <span>{tier.tier} - {tier.title}</span>
                </span>
              </div>
            </div>
          </div>

          {/* Quick Play Action */}
          <button
            type="button"
            onClick={() => { onStartDuel(); sound.playClick(); }}
            className="flex items-center gap-2 py-3 px-6 bg-gradient-to-r from-rose-500 to-pink-600 hover:from-rose-600 hover:to-pink-700 text-white font-pixel text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-rose-500/25 transition-all transform hover:-translate-y-0.5 cursor-pointer"
          >
            <Swords className="w-4 h-4" />
            <span>Enter Pixel Duel Arena</span>
          </button>
        </div>

        {/* Avatar Picker when Editing */}
        {isEditing && (
          <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
            <span className="text-xs font-mono text-slate-400">Select Pixel Avatar:</span>
            <div className="flex flex-wrap gap-2">
              {avatarOptions.map((av) => (
                <button
                  key={av}
                  type="button"
                  onClick={() => setSelectedAvatar(av)}
                  className={`w-10 h-10 rounded-lg text-xl flex items-center justify-center cursor-pointer transition-all ${
                    selectedAvatar === av
                      ? 'bg-rose-500/30 border-2 border-rose-500 scale-110'
                      : 'bg-slate-900 border border-slate-800 hover:bg-slate-800'
                  }`}
                >
                  {av}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* ELO Progress Bar towards next tier */}
        <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-xl space-y-3">
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="text-slate-400">
              Current Rating: <strong className="text-amber-400 font-pixel text-sm">{player.elo}</strong> ELO
            </span>
            {progress.nextTier ? (
              <span className="text-cyan-400 font-semibold">
                {progress.percentage}% towards {progress.nextTier.badge} {progress.nextTier.tier} ({progress.nextTier.minElo} ELO)
              </span>
            ) : (
              <span className="text-amber-400 font-bold">Max Tier Achieved! 👑</span>
            )}
          </div>

          <div className="w-full h-3 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
            <div 
              className="h-full bg-gradient-to-r from-rose-500 via-amber-400 to-cyan-400 transition-all duration-500"
              style={{ width: `${progress.percentage}%` }}
            />
          </div>
        </div>
      </div>

      {/* Career Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-xl text-center space-y-1">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Matches</span>
          <div className="font-pixel text-xl text-white">{totalMatches}</div>
        </div>

        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-xl text-center space-y-1">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Victories</span>
          <div className="font-pixel text-xl text-emerald-400">{player.wins}</div>
        </div>

        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-xl text-center space-y-1">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Defeats</span>
          <div className="font-pixel text-xl text-rose-400">{player.losses}</div>
        </div>

        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-xl text-center space-y-1">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Win Rate</span>
          <div className="font-pixel text-xl text-cyan-400">{winRate}%</div>
        </div>

        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-xl text-center space-y-1">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Streak</span>
          <div className="font-pixel text-xl text-orange-400 flex items-center justify-center gap-1">
            <Flame className="w-4 h-4 fill-orange-500 text-orange-500" />
            {player.currentStreak}
          </div>
        </div>

        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-xl text-center space-y-1">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Best Streak</span>
          <div className="font-pixel text-xl text-amber-400">{player.bestStreak}</div>
        </div>
      </div>

      {/* Match History Showcase */}
      <div className="space-y-4">
        <h2 className="text-lg font-bold text-white font-pixel flex items-center gap-2">
          <History className="w-5 h-5 text-rose-500" />
          Match History & Art Showcase
        </h2>

        {matches.length === 0 ? (
          <div className="p-8 text-center bg-slate-900/60 border border-slate-800 rounded-xl text-slate-400 font-mono text-xs">
            No matches recorded yet. Jump into an arena duel to begin building your battle record!
          </div>
        ) : (
          <div className="space-y-3">
            {matches.map((match) => {
              const isWin = match.result === 'win';
              const isLoss = match.result === 'loss';

              return (
                <div
                  key={match.id}
                  className="p-4 bg-slate-900/90 border border-slate-800 rounded-xl flex flex-col md:flex-row items-center justify-between gap-4"
                >
                  {/* Left: Result badge, prompt, date, opponent */}
                  <div className="flex items-center gap-4 w-full md:w-auto">
                    <span className={`px-3 py-1.5 rounded-lg font-pixel text-xs uppercase ${
                      isWin 
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' 
                        : isLoss 
                        ? 'bg-rose-950 text-rose-400 border border-rose-800' 
                        : 'bg-slate-800 text-slate-300'
                    }`}>
                      {match.result}
                    </span>

                    <div>
                      <h3 className="font-bold text-sm text-white">"{match.prompt}"</h3>
                      <div className="flex items-center gap-2 text-xs font-mono text-slate-400 mt-0.5">
                        <span>vs {match.opponentName} ({match.opponentElo} ELO)</span>
                        <span>•</span>
                        <span>{match.date}</span>
                      </div>
                    </div>
                  </div>

                  {/* Middle: Pixel Artworks Mini Showcase */}
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <div className="text-center">
                        <span className="text-[10px] font-mono text-rose-400 block mb-1">Your Art</span>
                        <div 
                          className="w-14 h-14 bg-slate-950 border border-slate-800 rounded grid overflow-hidden pixel-art"
                          style={{ gridTemplateColumns: `repeat(${match.myGrid.length}, minmax(0, 1fr))` }}
                        >
                          {match.myGrid.map((row, r) =>
                            row.map((c, idx) => (
                              <div
                                key={`my-${r}-${idx}`}
                                style={{ backgroundColor: c && c !== 'transparent' ? c : '#0a0f1d' }}
                                className="w-full h-full"
                              />
                            ))
                          )}
                        </div>
                      </div>

                      <span className="text-xs font-pixel text-slate-600">VS</span>

                      <div className="text-center">
                        <span className="text-[10px] font-mono text-cyan-400 block mb-1">Rival Art</span>
                        <div 
                          className="w-14 h-14 bg-slate-950 border border-slate-800 rounded grid overflow-hidden pixel-art"
                          style={{ gridTemplateColumns: `repeat(${match.opponentGrid.length}, minmax(0, 1fr))` }}
                        >
                          {match.opponentGrid.map((row, r) =>
                            row.map((c, idx) => (
                              <div
                                key={`opp-${r}-${idx}`}
                                style={{ backgroundColor: c && c !== 'transparent' ? c : '#0a0f1d' }}
                                className="w-full h-full"
                              />
                            ))
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Right: ELO change & Download button */}
                  <div className="flex items-center gap-3 w-full md:w-auto justify-end">
                    <div className="text-right">
                      <span className={`font-pixel text-sm font-bold ${
                        match.eloChange >= 0 ? 'text-emerald-400' : 'text-rose-400'
                      }`}>
                        {match.eloChange >= 0 ? `+${match.eloChange}` : match.eloChange} ELO
                      </span>
                      <div className="text-[11px] font-mono text-slate-400">
                        {match.myVotes} - {match.opponentVotes} votes
                      </div>
                    </div>

                    <button
                      type="button"
                      title="Download my artwork"
                      onClick={() => handleDownloadMatchArt(match)}
                      className="p-2 text-slate-400 hover:text-emerald-400 bg-slate-950 border border-slate-800 hover:border-slate-700 rounded-lg cursor-pointer transition-colors"
                    >
                      <Download className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
