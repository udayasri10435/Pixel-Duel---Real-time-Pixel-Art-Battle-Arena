import React, { useState } from 'react';
import { Player } from '../types/game';
import { ELO_TIERS, getEloTier } from '../utils/elo';
import { sound } from '../utils/audio';
import { 
  Trophy, 
  Search, 
  Flame, 
  Medal, 
  ChevronUp, 
  ChevronDown, 
  Sparkles,
  Users
} from 'lucide-react';

interface LeaderboardViewProps {
  players: Player[];
  currentPlayerId: string;
}

export const LeaderboardView: React.FC<LeaderboardViewProps> = ({
  players,
  currentPlayerId,
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedTier, setSelectedTier] = useState<string>('All');

  const filteredPlayers = players
    .filter((p) => {
      const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase());
      if (!matchesSearch) return false;
      if (selectedTier === 'All') return true;
      const tier = getEloTier(p.elo);
      return tier.tier === selectedTier;
    })
    .sort((a, b) => b.elo - a.elo);

  return (
    <div className="max-w-6xl mx-auto px-2 sm:px-4 py-4 space-y-6">
      {/* Header Banner */}
      <div className="p-6 bg-gradient-to-r from-slate-900 via-amber-950/20 to-slate-900 border-2 border-amber-500/30 rounded-2xl shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 to-yellow-300 flex items-center justify-center shadow-lg shadow-amber-500/20 flex-shrink-0">
            <Trophy className="w-7 h-7 text-slate-950" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-pixel text-xs text-amber-400">GLOBAL LEAGUE</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono border border-amber-500/30">
                SEASON 1
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
              Pixel Duel ELO Rankings
            </h1>
            <p className="text-xs font-mono text-slate-400 mt-1">
              Authoritative competitive ranking powered by real-time community votes.
            </p>
          </div>
        </div>

        {/* Tier Stats Summary */}
        <div className="flex items-center gap-2 flex-wrap">
          {ELO_TIERS.map((t) => (
            <div
              key={t.tier}
              onClick={() => {
                setSelectedTier(selectedTier === t.tier ? 'All' : t.tier);
                sound.playClick();
              }}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg border text-xs font-mono cursor-pointer transition-all ${
                selectedTier === t.tier 
                  ? 'border-amber-400 bg-amber-500/20 text-white font-bold' 
                  : 'border-slate-800 bg-slate-900/80 text-slate-400 hover:text-white'
              }`}
              title={`${t.tier}: ${t.minElo}+ ELO`}
            >
              <span>{t.badge}</span>
              <span className="hidden sm:inline">{t.tier}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Tier Badges Reference Roadmap */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
        {ELO_TIERS.map((t) => (
          <div 
            key={t.tier}
            className={`p-2.5 rounded-xl border flex flex-col items-center text-center transition-all ${t.borderClass} ${t.bgClass}`}
          >
            <span className="text-2xl mb-1">{t.badge}</span>
            <span className="text-xs font-bold">{t.tier}</span>
            <span className="text-[10px] font-mono text-slate-400">{t.minElo}+ ELO</span>
            <span className="text-[9px] font-mono text-slate-400 truncate max-w-full">{t.title}</span>
          </div>
        ))}
      </div>

      {/* Search & Filter Controls */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3 bg-slate-900/90 border border-slate-800 rounded-xl">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search artist by name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 outline-none focus:border-amber-500"
          />
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
          <Users className="w-4 h-4 text-slate-400" />
          <span>Showing <strong>{filteredPlayers.length}</strong> competitors</span>
        </div>
      </div>

      {/* Leaderboard Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 font-mono text-xs uppercase tracking-wider">
                <th className="py-3 px-4 w-16">Rank</th>
                <th className="py-3 px-4">Artist</th>
                <th className="py-3 px-4">Tier</th>
                <th className="py-3 px-4 text-right">ELO Rating</th>
                <th className="py-3 px-4 text-center">Record (W/L/D)</th>
                <th className="py-3 px-4 text-right">Win Rate</th>
                <th className="py-3 px-4 text-center">Streak</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-xs sm:text-sm font-mono">
              {filteredPlayers.map((player, idx) => {
                const rank = idx + 1;
                const tier = getEloTier(player.elo);
                const isCurrent = player.id === currentPlayerId;
                const total = player.wins + player.losses + player.draws;
                const winRate = total > 0 ? Math.round((player.wins / total) * 100) : 0;

                const rankBadge = 
                  rank === 1 ? '🥇' : 
                  rank === 2 ? '🥈' : 
                  rank === 3 ? '🥉' : 
                  `#${rank}`;

                return (
                  <tr
                    key={player.id}
                    className={`transition-colors ${
                      isCurrent 
                        ? 'bg-rose-950/30 hover:bg-rose-900/40 text-white font-semibold' 
                        : 'hover:bg-slate-800/40 text-slate-300'
                    }`}
                  >
                    {/* Rank */}
                    <td className="py-3 px-4">
                      <span className={`font-pixel text-xs ${
                        rank === 1 ? 'text-amber-400 font-bold text-sm' :
                        rank === 2 ? 'text-slate-300' :
                        rank === 3 ? 'text-amber-600' : 'text-slate-500'
                      }`}>
                        {rankBadge}
                      </span>
                    </td>

                    {/* Artist Name & Avatar */}
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2.5">
                        <span className="text-xl">{player.avatar}</span>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-bold text-white">{player.name}</span>
                            {isCurrent && (
                              <span className="px-1.5 py-0.2 bg-rose-500 text-white text-[10px] rounded font-mono">
                                YOU
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-slate-500 font-mono">
                            {player.matchesPlayed} battles fought
                          </span>
                        </div>
                      </div>
                    </td>

                    {/* Tier */}
                    <td className="py-3 px-4">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs border ${tier.borderClass} ${tier.bgClass}`}>
                        <span>{tier.badge}</span>
                        <span>{tier.tier}</span>
                      </span>
                    </td>

                    {/* ELO Rating */}
                    <td className="py-3 px-4 text-right">
                      <span className="font-pixel text-sm sm:text-base text-amber-400 font-bold">
                        {player.elo}
                      </span>
                    </td>

                    {/* Record */}
                    <td className="py-3 px-4 text-center text-slate-400">
                      <span className="text-emerald-400 font-semibold">{player.wins}W</span>
                      <span className="mx-1 text-slate-600">/</span>
                      <span className="text-rose-400">{player.losses}L</span>
                      <span className="mx-1 text-slate-600">/</span>
                      <span className="text-slate-400">{player.draws}D</span>
                    </td>

                    {/* Win Rate */}
                    <td className="py-3 px-4 text-right">
                      <span className={`font-semibold ${winRate >= 60 ? 'text-emerald-400' : winRate >= 45 ? 'text-amber-400' : 'text-slate-400'}`}>
                        {winRate}%
                      </span>
                    </td>

                    {/* Streak */}
                    <td className="py-3 px-4 text-center">
                      {player.currentStreak > 0 ? (
                        <span className="inline-flex items-center gap-1 text-orange-400 font-bold">
                          <Flame className="w-3.5 h-3.5 fill-orange-500 text-orange-500" />
                          {player.currentStreak}
                        </span>
                      ) : (
                        <span className="text-slate-600">-</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
