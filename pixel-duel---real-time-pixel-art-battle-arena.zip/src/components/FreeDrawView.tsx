import React, { useState } from 'react';
import { PixelGrid } from '../types/game';
import { PixelCanvas } from './PixelCanvas';
import { getRandomPrompt, PROMPT_LIST, PromptItem } from '../utils/prompts';
import { createEmptyGrid } from '../utils/palettes';
import { sound } from '../utils/audio';
import { 
  Palette, 
  Shuffle, 
  Sparkles, 
  Clock, 
  Download, 
  Swords, 
  Layers
} from 'lucide-react';

interface FreeDrawViewProps {
  onQueueForDuel: () => void;
}

export const FreeDrawView: React.FC<FreeDrawViewProps> = ({ onQueueForDuel }) => {
  const [currentPrompt, setCurrentPrompt] = useState<PromptItem>(getRandomPrompt);
  const [gridSize, setGridSize] = useState<number>(16);
  const [grid, setGrid] = useState<PixelGrid>(() => createEmptyGrid(16));
  const [showPrompt, setShowPrompt] = useState<boolean>(true);

  const handleReroll = () => {
    setCurrentPrompt(getRandomPrompt());
    sound.playClick();
  };

  const handleClear = () => {
    setGrid(createEmptyGrid(gridSize));
    sound.playErase();
  };

  return (
    <div className="max-w-5xl mx-auto px-2 sm:px-4 py-4 space-y-4">
      {/* Header Banner */}
      <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 via-teal-950/20 to-slate-900 border-2 border-slate-800 rounded-2xl shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-teal-500 to-cyan-500 flex items-center justify-center text-white flex-shrink-0">
            <Palette className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-pixel text-xs text-teal-400">PRACTICE STUDIO</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-teal-950 text-teal-300 font-mono border border-teal-800">
                UNLIMITED TIME
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-white mt-0.5">
              Solo Pixel Sandbox & Warmup
            </h1>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleReroll}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-mono cursor-pointer"
          >
            <Shuffle className="w-3.5 h-3.5" />
            <span>Random Prompt</span>
          </button>

          <button
            type="button"
            onClick={() => { onQueueForDuel(); sound.playClick(); }}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white font-pixel text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-rose-500/25 cursor-pointer"
          >
            <Swords className="w-4 h-4" />
            <span>Ready for Duel</span>
          </button>
        </div>
      </div>

      {/* Suggested Prompt Card */}
      {showPrompt && (
        <div className="p-3.5 bg-slate-900/90 border border-slate-800 rounded-xl flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <Sparkles className="w-4 h-4 text-amber-400 flex-shrink-0" />
            <div>
              <span className="text-[10px] font-mono uppercase text-slate-400">Warmup Prompt: </span>
              <strong className="text-amber-300 text-sm">"{currentPrompt.prompt}"</strong>
              <span className="ml-2 text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">
                {currentPrompt.category}
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={handleReroll}
            className="text-xs text-rose-400 hover:text-rose-300 font-mono cursor-pointer flex-shrink-0"
          >
            New Idea →
          </button>
        </div>
      )}

      {/* Main Sandbox Canvas */}
      <div className="max-w-2xl mx-auto p-4 bg-slate-900/90 border border-slate-800 rounded-2xl shadow-xl">
        <PixelCanvas
          grid={grid}
          onChange={setGrid}
          size={gridSize}
          showControls={true}
        />
      </div>
    </div>
  );
};
