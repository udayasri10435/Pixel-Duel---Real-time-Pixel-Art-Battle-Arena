import React, { useState, useEffect } from 'react';
import { Player } from '../types/game';
import { getEloTier } from '../utils/elo';
import { sound } from '../utils/audio';
import { 
  Swords, 
  Bot, 
  X, 
  Radio, 
  ShieldAlert, 
  Sparkles,
  Search
} from 'lucide-react';

interface MatchmakingModalProps {
  player: Player;
  onCancel: () => void;
  onStartBotMatch: () => void;
}

export const MatchmakingModal: React.FC<MatchmakingModalProps> = ({
  player,
  onCancel,
  onStartBotMatch,
}) => {
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);
  const tier = getEloTier(player.elo);

  useEffect(() => {
    const timer = setInterval(() => {
      setElapsedSeconds((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-md p-6 bg-slate-900 border-2 border-rose-500/40 rounded-2xl shadow-2xl space-y-6 text-center overflow-hidden">
        {/* Glowing Radar Background */}
        <div className="absolute -top-12 -right-12 w-48 h-48 bg-rose-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-12 -left-12 w-48 h-48 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />

        {/* Close Button */}
        <button
          type="button"
          onClick={() => { onCancel(); sound.playClick(); }}
          className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white rounded-lg bg-slate-800/80 hover:bg-slate-700 cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Animated Radar Pulse */}
        <div className="relative w-28 h-28 mx-auto flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-rose-500/30 animate-ping opacity-75" />
          <div className="absolute inset-2 rounded-full border-2 border-cyan-500/40 animate-pulse" />
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-rose-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-rose-500/30 text-white z-10">
            <Swords className="w-8 h-8 animate-pulse" />
          </div>
        </div>

        {/* Status Text */}
        <div className="space-y-1">
          <h2 className="font-pixel text-base text-white tracking-wide">
            SEARCHING FOR CHALLENGER...
          </h2>
          <p className="text-xs font-mono text-slate-400">
            Matching skill range: <strong className="text-amber-400">{player.elo - 100} - {player.elo + 100} ELO</strong>
          </p>
          <div className="font-mono text-cyan-400 text-xs pt-1">
            Queue time: {elapsedSeconds}s
          </div>
        </div>

        {/* Current Player Card */}
        <div className="flex items-center justify-center gap-3 p-3 bg-slate-950 border border-slate-800 rounded-xl">
          <span className="text-2xl">{player.avatar}</span>
          <div className="text-left">
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-white text-xs">{player.name}</span>
              <span title={tier.title}>{tier.badge}</span>
            </div>
            <div className="text-[11px] font-mono text-slate-400">
              {player.elo} ELO • {player.wins}W / {player.losses}L
            </div>
          </div>
        </div>

        {/* Instant Bot Duel Alternative */}
        <div className="p-3 bg-gradient-to-r from-indigo-950/40 to-slate-900 border border-indigo-800/50 rounded-xl space-y-2">
          <div className="flex items-center justify-center gap-2 text-xs font-mono text-indigo-300">
            <Bot className="w-4 h-4 text-cyan-400" />
            <span>Don't want to wait for a live match?</span>
          </div>
          <button
            type="button"
            onClick={() => { onStartBotMatch(); sound.playClick(); }}
            className="w-full py-2.5 px-4 bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white font-pixel text-xs uppercase tracking-wider rounded-lg shadow-md cursor-pointer transition-all"
          >
            Play vs PixelBot Now 🤖
          </button>
        </div>

        {/* Cancel Button */}
        <button
          type="button"
          onClick={() => { onCancel(); sound.playClick(); }}
          className="w-full py-2 text-xs font-mono text-slate-400 hover:text-white cursor-pointer"
        >
          Cancel Matchmaking
        </button>
      </div>
    </div>
  );
};
