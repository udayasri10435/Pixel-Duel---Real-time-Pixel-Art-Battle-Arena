import React from 'react';
import { Player } from '../types/game';
import { getEloTier } from '../utils/elo';
import { sound } from '../utils/audio';
import { 
  Swords, 
  Vote, 
  Trophy, 
  Users, 
  Palette as PaletteIcon, 
  User, 
  Volume2, 
  VolumeX, 
  Flame,
  Radio
} from 'lucide-react';

interface NavbarProps {
  currentTab: 'arena' | 'voting' | 'leaderboard' | 'local' | 'freedraw' | 'profile';
  onSelectTab: (tab: 'arena' | 'voting' | 'leaderboard' | 'local' | 'freedraw' | 'profile') => void;
  player: Player;
  soundEnabled: boolean;
  onToggleSound: () => void;
  activeVotingCount: number;
  onlineCount: number;
  isConnected: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  player,
  soundEnabled,
  onToggleSound,
  activeVotingCount,
  onlineCount,
  isConnected,
}) => {
  const tier = getEloTier(player.elo);

  const navItems = [
    { id: 'arena', label: '1v1 Duel', icon: Swords, badge: undefined },
    { id: 'voting', label: 'Voting Arena', icon: Vote, badge: activeVotingCount > 0 ? activeVotingCount : undefined },
    { id: 'leaderboard', label: 'ELO Ladder', icon: Trophy, badge: undefined },
    { id: 'local', label: 'Local 2P', icon: Users, badge: undefined },
    { id: 'freedraw', label: 'Free Draw', icon: PaletteIcon, badge: undefined },
    { id: 'profile', label: 'My Stats', icon: User, badge: undefined },
  ] as const;

  return (
    <header className="sticky top-0 z-50 bg-slate-950/90 backdrop-blur-md border-b border-slate-800 shadow-xl">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 h-16 flex items-center justify-between gap-2">
        {/* Brand / Title */}
        <div 
          onClick={() => { onSelectTab('arena'); sound.playClick(); }}
          className="flex items-center gap-2.5 cursor-pointer group"
        >
          <div className="relative w-9 h-9 rounded-lg bg-gradient-to-br from-rose-500 via-pink-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-rose-500/25 border border-rose-400/40 transform group-hover:scale-105 transition-transform">
            <Swords className="w-5 h-5 text-white" />
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-cyan-400 rounded-full animate-ping opacity-75" />
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-pixel text-sm sm:text-base font-bold bg-gradient-to-r from-rose-400 via-pink-300 to-cyan-300 bg-clip-text text-transparent">
                PIXEL DUEL
              </span>
              <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30">
                LIVE
              </span>
            </div>
            <p className="text-[10px] text-slate-400 font-mono hidden sm:block">
              Simultaneous Draw • Community Vote • ELO
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="hidden md:flex items-center gap-1 bg-slate-900/80 p-1 rounded-xl border border-slate-800/80">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  onSelectTab(item.id);
                  sound.playClick();
                }}
                className={`relative flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-all ${
                  isActive
                    ? 'bg-rose-500 text-white shadow-md shadow-rose-500/20'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
                {item.badge !== undefined && (
                  <span className="ml-1 px-1.5 py-0.2 bg-cyan-500 text-slate-950 font-bold text-[10px] rounded-full animate-pulse">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Right Section: Player ELO Card & Controls */}
        <div className="flex items-center gap-2">
          {/* Player Quick Badge */}
          <div 
            onClick={() => { onSelectTab('profile'); sound.playClick(); }}
            className="flex items-center gap-2 px-2.5 py-1.5 bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-lg cursor-pointer transition-all shadow-sm group"
          >
            <span className="text-lg leading-none">{player.avatar}</span>
            <div className="flex flex-col text-left">
              <div className="flex items-center gap-1">
                <span className="text-xs font-semibold text-slate-200 group-hover:text-rose-400 transition-colors truncate max-w-[80px] sm:max-w-[110px]">
                  {player.name}
                </span>
                <span title={tier.title}>{tier.badge}</span>
              </div>
              <div className="flex items-center gap-1 text-[11px] font-mono">
                <span className="text-amber-400 font-bold">{player.elo}</span>
                <span className="text-slate-500 text-[10px]">ELO</span>
                {player.currentStreak > 1 && (
                  <span className="flex items-center text-[10px] text-orange-400 ml-1">
                    <Flame className="w-3 h-3 fill-orange-500 text-orange-500" />
                    {player.currentStreak}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Sound Toggle */}
          <button
            type="button"
            title={soundEnabled ? 'Mute 8-bit Audio' : 'Unmute 8-bit Audio'}
            onClick={() => {
              onToggleSound();
              sound.playClick();
            }}
            className="p-2 text-slate-400 hover:text-white bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-lg cursor-pointer transition-colors"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>

          {/* Connection Status Indicator */}
          <div 
            className="hidden sm:flex items-center gap-1.5 px-2 py-1 bg-slate-900 border border-slate-800 rounded-lg text-[11px] font-mono text-slate-400"
            title={isConnected ? 'Connected to live battle server' : 'Reconnecting...'}
          >
            <Radio className={`w-3 h-3 ${isConnected ? 'text-emerald-400 animate-pulse' : 'text-amber-500'}`} />
            <span>{onlineCount} live</span>
          </div>
        </div>
      </div>

      {/* Mobile Bottom Navigation */}
      <div className="md:hidden flex items-center justify-around border-t border-slate-800 bg-slate-950 px-1 py-1.5">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                onSelectTab(item.id);
                sound.playClick();
              }}
              className={`flex flex-col items-center gap-0.5 p-1 rounded text-[10px] ${
                isActive ? 'text-rose-400 font-bold' : 'text-slate-400'
              }`}
            >
              <div className="relative">
                <Icon className="w-4 h-4" />
                {item.badge !== undefined && (
                  <span className="absolute -top-1 -right-2 px-1 bg-cyan-500 text-slate-950 font-bold text-[8px] rounded-full">
                    {item.badge}
                  </span>
                )}
              </div>
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
