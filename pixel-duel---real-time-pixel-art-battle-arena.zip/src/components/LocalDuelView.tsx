import React, { useState, useEffect } from 'react';
import { PixelGrid } from '../types/game';
import { PixelCanvas } from './PixelCanvas';
import { getRandomPrompt } from '../utils/prompts';
import { createEmptyGrid } from '../utils/palettes';
import { sound } from '../utils/audio';
import confetti from 'canvas-confetti';
import { 
  Users, 
  Timer, 
  RotateCcw, 
  Sparkles, 
  Trophy, 
  Play, 
  Shuffle,
  Swords
} from 'lucide-react';

export const LocalDuelView: React.FC = () => {
  const [promptItem, setPromptItem] = useState(getRandomPrompt);
  const [gridSize, setGridSize] = useState<number>(16);
  const [grid1, setGrid1] = useState<PixelGrid>(() => createEmptyGrid(16));
  const [grid2, setGrid2] = useState<PixelGrid>(() => createEmptyGrid(16));

  const [phase, setPhase] = useState<'setup' | 'drawing' | 'judging'>('setup');
  const [duration, setDuration] = useState<number>(60);
  const [timeLeft, setTimeLeft] = useState<number>(60);
  const [localWinner, setLocalWinner] = useState<'player1' | 'player2' | 'tie' | null>(null);

  // Authoritative local clock
  useEffect(() => {
    if (phase !== 'drawing') return;
    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setPhase('judging');
          sound.playCountdown(true);
          return 0;
        }
        if (prev <= 4) {
          sound.playCountdown(false);
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [phase]);

  const handleStartDuel = () => {
    setGrid1(createEmptyGrid(gridSize));
    setGrid2(createEmptyGrid(gridSize));
    setTimeLeft(duration);
    setLocalWinner(null);
    setPhase('drawing');
    sound.playMatchStart();
  };

  const handlePickWinner = (winner: 'player1' | 'player2' | 'tie') => {
    setLocalWinner(winner);
    sound.playVictory();
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 },
    });
  };

  const handleNewRound = () => {
    setPromptItem(getRandomPrompt());
    setGrid1(createEmptyGrid(gridSize));
    setGrid2(createEmptyGrid(gridSize));
    setTimeLeft(duration);
    setLocalWinner(null);
    setPhase('setup');
    sound.playClick();
  };

  return (
    <div className="max-w-7xl mx-auto px-2 sm:px-4 py-4 space-y-4">
      {/* Header Banner */}
      <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 via-purple-950/20 to-slate-900 border-2 border-slate-800 rounded-2xl shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-purple-500 to-indigo-600 flex items-center justify-center text-white flex-shrink-0">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-pixel text-xs text-purple-400">SPLIT-SCREEN 2-PLAYER</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-purple-950 text-purple-300 font-mono border border-purple-800">
                LOCAL PASS & PLAY
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-white mt-0.5">
              "{promptItem.prompt}"
            </h1>
          </div>
        </div>

        {/* Status / Clock */}
        <div className="flex items-center gap-3">
          {phase === 'drawing' && (
            <div className="flex items-center gap-2 px-4 py-2 bg-slate-950 border border-slate-800 rounded-xl">
              <Timer className={`w-5 h-5 ${timeLeft <= 10 ? 'text-rose-500 animate-pulse' : 'text-emerald-400'}`} />
              <span className="font-pixel text-2xl text-white">{timeLeft}s</span>
            </div>
          )}

          {phase === 'setup' && (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setPromptItem(getRandomPrompt())}
                className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-mono cursor-pointer"
              >
                <Shuffle className="w-3.5 h-3.5" />
                <span>Reroll Prompt</span>
              </button>

              <button
                type="button"
                onClick={handleStartDuel}
                className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-pixel text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-purple-500/25 cursor-pointer"
              >
                <Play className="w-3.5 h-3.5" />
                <span>Start Match</span>
              </button>
            </div>
          )}

          {phase === 'judging' && (
            <button
              type="button"
              onClick={handleNewRound}
              className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-mono cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>New Round</span>
            </button>
          )}
        </div>
      </div>

      {/* Judging Phase Banner */}
      {phase === 'judging' && (
        <div className="p-4 bg-slate-900 border-2 border-amber-500/50 rounded-xl text-center space-y-2">
          <Trophy className="w-8 h-8 text-amber-400 mx-auto" />
          <h2 className="font-pixel text-base text-amber-300">TIME IS UP! PICK THE CHAMPION</h2>
          <p className="text-xs font-mono text-slate-400">
            Compare both artworks side-by-side. Who captured "{promptItem.prompt}" best?
          </p>

          <div className="flex items-center justify-center gap-4 pt-2">
            <button
              type="button"
              onClick={() => handlePickWinner('player1')}
              className={`px-4 py-2 font-pixel text-xs rounded-xl cursor-pointer transition-all ${
                localWinner === 'player1' 
                  ? 'bg-rose-500 text-white ring-2 ring-white scale-105' 
                  : 'bg-rose-950/60 border border-rose-600 text-rose-300 hover:bg-rose-900'
              }`}
            >
              Player 1 Wins! 👑
            </button>

            <button
              type="button"
              onClick={() => handlePickWinner('tie')}
              className={`px-4 py-2 font-pixel text-xs rounded-xl cursor-pointer transition-all ${
                localWinner === 'tie' 
                  ? 'bg-slate-600 text-white ring-2 ring-white scale-105' 
                  : 'bg-slate-800 border border-slate-700 text-slate-300 hover:bg-slate-700'
              }`}
            >
              It's a Draw 🤝
            </button>

            <button
              type="button"
              onClick={() => handlePickWinner('player2')}
              className={`px-4 py-2 font-pixel text-xs rounded-xl cursor-pointer transition-all ${
                localWinner === 'player2' 
                  ? 'bg-cyan-500 text-white ring-2 ring-white scale-105' 
                  : 'bg-cyan-950/60 border border-cyan-600 text-cyan-300 hover:bg-cyan-900'
              }`}
            >
              Player 2 Wins! 👑
            </button>
          </div>
        </div>
      )}

      {/* Split Dual Canvas Stage */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Player 1 Side */}
        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-2xl space-y-3">
          <div className="flex items-center justify-between">
            <span className="font-pixel text-xs text-rose-400">PLAYER 1 (RED)</span>
            {localWinner === 'player1' && (
              <span className="font-pixel text-xs text-amber-400 animate-bounce">VICTORIOUS! 👑</span>
            )}
          </div>
          <PixelCanvas
            grid={grid1}
            onChange={setGrid1}
            size={gridSize}
            readOnly={phase === 'judging'}
            showControls={true}
          />
        </div>

        {/* Player 2 Side */}
        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-2xl space-y-3">
          <div className="flex items-center justify-between">
            <span className="font-pixel text-xs text-cyan-400">PLAYER 2 (CYAN)</span>
            {localWinner === 'player2' && (
              <span className="font-pixel text-xs text-amber-400 animate-bounce">VICTORIOUS! 👑</span>
            )}
          </div>
          <PixelCanvas
            grid={grid2}
            onChange={setGrid2}
            size={gridSize}
            readOnly={phase === 'judging'}
            showControls={true}
          />
        </div>
      </div>
    </div>
  );
};
