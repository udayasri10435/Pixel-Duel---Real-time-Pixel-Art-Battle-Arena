import React, { useState, useRef, useEffect, useCallback } from 'react';
import { PixelGrid, ToolType, Palette } from '../types/game';
import { RETRO_PALETTES, cloneGrid, floodFill, drawLine, drawRect, countDrawnPixels, exportGridToDataUrl } from '../utils/palettes';
import { sound } from '../utils/audio';
import { 
  Paintbrush, 
  Eraser, 
  PaintBucket, 
  Pipette, 
  Minus, 
  Square, 
  Grid3X3, 
  RotateCcw, 
  RotateCw, 
  Trash2, 
  Download, 
  ZoomIn, 
  ZoomOut,
  Sparkles
} from 'lucide-react';

interface PixelCanvasProps {
  grid: PixelGrid;
  onChange: (newGrid: PixelGrid) => void;
  size?: number;
  readOnly?: boolean;
  activeColor?: string;
  onColorChange?: (color: string) => void;
  showControls?: boolean;
  className?: string;
}

export const PixelCanvas: React.FC<PixelCanvasProps> = ({
  grid,
  onChange,
  size = 16,
  readOnly = false,
  activeColor: externalColor,
  onColorChange: externalColorChange,
  showControls = true,
  className = '',
}) => {
  const [internalColor, setInternalColor] = useState<string>('#ffffff');
  const currentColor = externalColor ?? internalColor;
  const setCurrentColor = externalColorChange ?? setInternalColor;

  const [currentTool, setCurrentTool] = useState<ToolType>('pencil');
  const [brushSize, setBrushSize] = useState<number>(1);
  const [showGridLines, setShowGridLines] = useState<boolean>(true);
  const [selectedPalette, setSelectedPalette] = useState<Palette>(RETRO_PALETTES[0]);
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [customColor, setCustomColor] = useState<string>('#f43f5e');

  // History stack for undo/redo
  const historyRef = useRef<PixelGrid[]>([cloneGrid(grid)]);
  const historyIndexRef = useRef<number>(0);

  // Dragging / drawing states
  const [isDrawing, setIsDrawing] = useState<boolean>(false);
  const startCoordRef = useRef<{ x: number; y: number } | null>(null);
  const [previewCoord, setPreviewCoord] = useState<{ x: number; y: number } | null>(null);
  const [cursorPos, setCursorPos] = useState<{ x: number; y: number } | null>(null);

  const canvasContainerRef = useRef<HTMLDivElement>(null);

  // Sync initial grid into history if empty
  useEffect(() => {
    if (historyRef.current.length === 0) {
      historyRef.current = [cloneGrid(grid)];
      historyIndexRef.current = 0;
    }
  }, [grid]);

  const pushToHistory = useCallback((newGrid: PixelGrid) => {
    const trimmed = historyRef.current.slice(0, historyIndexRef.current + 1);
    trimmed.push(cloneGrid(newGrid));
    if (trimmed.length > 30) trimmed.shift(); // keep max 30 states
    historyRef.current = trimmed;
    historyIndexRef.current = trimmed.length - 1;
    onChange(newGrid);
  }, [onChange]);

  const handleUndo = useCallback(() => {
    if (historyIndexRef.current > 0) {
      historyIndexRef.current--;
      const targetGrid = cloneGrid(historyRef.current[historyIndexRef.current]);
      onChange(targetGrid);
      sound.playClick();
    }
  }, [onChange]);

  const handleRedo = useCallback(() => {
    if (historyIndexRef.current < historyRef.current.length - 1) {
      historyIndexRef.current++;
      const targetGrid = cloneGrid(historyRef.current[historyIndexRef.current]);
      onChange(targetGrid);
      sound.playClick();
    }
  }, [onChange]);

  // Keyboard shortcuts (Z for undo, Y for redo)
  useEffect(() => {
    if (readOnly) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        if (e.shiftKey) {
          handleRedo();
        } else {
          handleUndo();
        }
      } else if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'y') {
        e.preventDefault();
        handleRedo();
      } else if (e.key.toLowerCase() === 'b') {
        setCurrentTool('pencil');
      } else if (e.key.toLowerCase() === 'e') {
        setCurrentTool('eraser');
      } else if (e.key.toLowerCase() === 'g') {
        setCurrentTool('bucket');
      } else if (e.key.toLowerCase() === 'i') {
        setCurrentTool('picker');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleUndo, handleRedo, readOnly]);

  const applyPixelToGrid = (
    baseGrid: PixelGrid,
    x: number,
    y: number,
    color: string,
    tool: ToolType,
    ditherPattern: boolean = false
  ): PixelGrid => {
    const target = cloneGrid(baseGrid);
    const maxY = target.length;
    const maxX = target[0]?.length || 0;

    const paint = (cx: number, cy: number, c: string) => {
      if (cx >= 0 && cx < maxX && cy >= 0 && cy < maxY) {
        if (ditherPattern && (cx + cy) % 2 !== 0) {
          return; // skip every alternate pixel for dithering
        }
        target[cy][cx] = c;
      }
    };

    if (tool === 'eraser') {
      paint(x, y, 'transparent');
      if (brushSize > 1) {
        paint(x + 1, y, 'transparent');
        paint(x, y + 1, 'transparent');
        paint(x + 1, y + 1, 'transparent');
      }
    } else if (tool === 'pencil' || tool === 'dither') {
      paint(x, y, color);
      if (brushSize > 1 && tool === 'pencil') {
        paint(x + 1, y, color);
        paint(x, y + 1, color);
        paint(x + 1, y + 1, color);
      }
    }

    return target;
  };

  const handlePointerDown = (x: number, y: number, e: React.PointerEvent) => {
    if (readOnly) return;
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    setIsDrawing(true);
    startCoordRef.current = { x, y };
    setPreviewCoord({ x, y });

    if (currentTool === 'picker') {
      const picked = grid[y]?.[x];
      if (picked && picked !== 'transparent') {
        setCurrentColor(picked);
        sound.playPixelPlace(4);
      }
      setCurrentTool('pencil');
      setIsDrawing(false);
      return;
    }

    if (currentTool === 'bucket') {
      const targetColor = grid[y]?.[x] || 'transparent';
      const filled = floodFill(grid, x, y, targetColor, currentColor);
      pushToHistory(filled);
      sound.playFill();
      setIsDrawing(false);
      return;
    }

    if (currentTool === 'pencil' || currentTool === 'eraser' || currentTool === 'dither') {
      const updated = applyPixelToGrid(
        grid, 
        x, 
        y, 
        currentColor, 
        currentTool, 
        currentTool === 'dither'
      );
      onChange(updated);
      if (currentTool === 'eraser') {
        sound.playErase();
      } else {
        sound.playPixelPlace();
      }
    }
  };

  const handlePointerMove = (x: number, y: number) => {
    setCursorPos({ x, y });
    if (!isDrawing || readOnly) return;

    if (currentTool === 'pencil' || currentTool === 'eraser' || currentTool === 'dither') {
      const updated = applyPixelToGrid(
        grid, 
        x, 
        y, 
        currentColor, 
        currentTool, 
        currentTool === 'dither'
      );
      onChange(updated);
    } else if (currentTool === 'line' || currentTool === 'rect') {
      setPreviewCoord({ x, y });
    }
  };

  const handlePointerUp = () => {
    if (!isDrawing || readOnly) return;
    setIsDrawing(false);

    if (startCoordRef.current && previewCoord) {
      if (currentTool === 'line') {
        const lineGrid = drawLine(
          grid,
          startCoordRef.current.x,
          startCoordRef.current.y,
          previewCoord.x,
          previewCoord.y,
          currentColor
        );
        pushToHistory(lineGrid);
        sound.playPixelPlace(2);
      } else if (currentTool === 'rect') {
        const rectGrid = drawRect(
          grid,
          startCoordRef.current.x,
          startCoordRef.current.y,
          previewCoord.x,
          previewCoord.y,
          currentColor,
          false
        );
        pushToHistory(rectGrid);
        sound.playPixelPlace(3);
      } else {
        // Pencil or Eraser stroke finished
        pushToHistory(grid);
      }
    }

    startCoordRef.current = null;
    setPreviewCoord(null);
  };

  const handleClear = () => {
    if (readOnly) return;
    const empty = cloneGrid(grid).map((row) => row.map(() => 'transparent'));
    pushToHistory(empty);
    sound.playErase();
  };

  const handleDownload = () => {
    const dataUrl = exportGridToDataUrl(grid, 24);
    if (!dataUrl) return;
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = `pixel-duel-art-${Date.now()}.png`;
    a.click();
    sound.playVictory();
  };

  // Compute preview overlay if drawing line/rect
  let displayGrid = grid;
  if (isDrawing && startCoordRef.current && previewCoord) {
    if (currentTool === 'line') {
      displayGrid = drawLine(
        grid,
        startCoordRef.current.x,
        startCoordRef.current.y,
        previewCoord.x,
        previewCoord.y,
        currentColor
      );
    } else if (currentTool === 'rect') {
      displayGrid = drawRect(
        grid,
        startCoordRef.current.x,
        startCoordRef.current.y,
        previewCoord.x,
        previewCoord.y,
        currentColor,
        false
      );
    }
  }

  const drawnCount = countDrawnPixels(grid);
  const totalPixels = size * size;

  return (
    <div className={`flex flex-col select-none ${className}`}>
      {/* Optional Top Mini-bar */}
      {showControls && (
        <div className="flex flex-wrap items-center justify-between gap-2 p-2 mb-2 bg-slate-900/90 border border-slate-800 rounded-lg shadow-sm">
          {/* Tool buttons */}
          <div className="flex items-center gap-1">
            <button
              type="button"
              title="Pencil (B)"
              onClick={() => { setCurrentTool('pencil'); sound.playClick(); }}
              className={`p-2 rounded cursor-pointer transition-all ${
                currentTool === 'pencil' 
                  ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/30' 
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Paintbrush className="w-4 h-4" />
            </button>

            <button
              type="button"
              title="Eraser (E)"
              onClick={() => { setCurrentTool('eraser'); sound.playClick(); }}
              className={`p-2 rounded cursor-pointer transition-all ${
                currentTool === 'eraser' 
                  ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/30' 
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Eraser className="w-4 h-4" />
            </button>

            <button
              type="button"
              title="Paint Bucket (G)"
              onClick={() => { setCurrentTool('bucket'); sound.playClick(); }}
              className={`p-2 rounded cursor-pointer transition-all ${
                currentTool === 'bucket' 
                  ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/30' 
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <PaintBucket className="w-4 h-4" />
            </button>

            <button
              type="button"
              title="Eyedropper / Color Picker (I)"
              onClick={() => { setCurrentTool('picker'); sound.playClick(); }}
              className={`p-2 rounded cursor-pointer transition-all ${
                currentTool === 'picker' 
                  ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/30' 
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Pipette className="w-4 h-4" />
            </button>

            <button
              type="button"
              title="Straight Line Tool"
              onClick={() => { setCurrentTool('line'); sound.playClick(); }}
              className={`p-2 rounded cursor-pointer transition-all ${
                currentTool === 'line' 
                  ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/30' 
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Minus className="w-4 h-4" />
            </button>

            <button
              type="button"
              title="Rectangle Outline Tool"
              onClick={() => { setCurrentTool('rect'); sound.playClick(); }}
              className={`p-2 rounded cursor-pointer transition-all ${
                currentTool === 'rect' 
                  ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/30' 
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Square className="w-4 h-4" />
            </button>

            <button
              type="button"
              title="Retro Dithering Shade Tool"
              onClick={() => { setCurrentTool('dither'); sound.playClick(); }}
              className={`p-2 rounded cursor-pointer transition-all ${
                currentTool === 'dither' 
                  ? 'bg-cyan-500 text-white shadow-lg shadow-cyan-500/30' 
                  : 'text-slate-400 hover:text-cyan-400 hover:bg-slate-800'
              }`}
            >
              <Sparkles className="w-4 h-4" />
            </button>
          </div>

          {/* Canvas Utilities: Undo, Redo, Grid, Clear, Download */}
          <div className="flex items-center gap-1">
            <button
              type="button"
              title="Undo (Ctrl+Z)"
              disabled={historyIndexRef.current <= 0}
              onClick={handleUndo}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded disabled:opacity-30 disabled:pointer-events-none cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <button
              type="button"
              title="Redo (Ctrl+Y)"
              disabled={historyIndexRef.current >= historyRef.current.length - 1}
              onClick={handleRedo}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded disabled:opacity-30 disabled:pointer-events-none cursor-pointer"
            >
              <RotateCw className="w-4 h-4" />
            </button>

            <div className="w-[1px] h-5 bg-slate-800 mx-1" />

            <button
              type="button"
              title="Toggle Grid Overlay"
              onClick={() => { setShowGridLines(!showGridLines); sound.playClick(); }}
              className={`p-2 rounded cursor-pointer ${
                showGridLines ? 'text-rose-400 bg-slate-800' : 'text-slate-500 hover:text-white'
              }`}
            >
              <Grid3X3 className="w-4 h-4" />
            </button>

            <button
              type="button"
              title="Download PNG"
              onClick={handleDownload}
              className="p-2 text-slate-400 hover:text-emerald-400 hover:bg-slate-800 rounded cursor-pointer"
            >
              <Download className="w-4 h-4" />
            </button>

            <button
              type="button"
              title="Clear Canvas"
              onClick={handleClear}
              className="p-2 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Main Pixel Canvas Area */}
      <div 
        ref={canvasContainerRef}
        className="relative flex items-center justify-center p-3 bg-slate-950/80 border-2 border-slate-800 rounded-xl overflow-hidden shadow-2xl backdrop-blur-md"
        onPointerUp={handlePointerUp}
        onPointerLeave={() => { handlePointerUp(); setCursorPos(null); }}
      >
        {/* Subtle checkerboard pattern for transparent pixels */}
        <div 
          className="relative inline-grid aspect-square touch-none cursor-crosshair rounded border border-slate-700/80 shadow-inner overflow-hidden"
          style={{
            gridTemplateColumns: `repeat(${size}, minmax(0, 1fr))`,
            width: '100%',
            maxWidth: `${size * 24}px`,
            backgroundImage: `
              linear-gradient(45deg, #131b2e 25%, transparent 25%), 
              linear-gradient(-45deg, #131b2e 25%, transparent 25%), 
              linear-gradient(45deg, transparent 75%, #131b2e 75%), 
              linear-gradient(-45deg, transparent 75%, #131b2e 75%)
            `,
            backgroundSize: '16px 16px',
            backgroundPosition: '0 0, 0 8px, 8px -8px, -8px 0px',
            backgroundColor: '#0a0f1d'
          }}
        >
          {displayGrid.map((row, r) =>
            row.map((cellColor, c) => {
              const isFilled = cellColor && cellColor !== 'transparent';
              return (
                <div
                  key={`${r}-${c}`}
                  onPointerDown={(e) => handlePointerDown(c, r, e)}
                  onPointerEnter={() => handlePointerMove(c, r)}
                  style={{
                    backgroundColor: isFilled ? cellColor : undefined,
                  }}
                  className={`w-full h-full aspect-square transition-[background-color] duration-75 ${
                    showGridLines ? 'border-r border-b border-white/5' : ''
                  } ${
                    cursorPos && cursorPos.x === c && cursorPos.y === r && !readOnly
                      ? 'outline outline-1 outline-white/80 z-10'
                      : ''
                  }`}
                />
              );
            })
          )}
        </div>
      </div>

      {/* Canvas Status & Coordinate Footer */}
      <div className="flex items-center justify-between text-xs font-mono text-slate-400 mt-2 px-1">
        <div className="flex items-center gap-3">
          <span>
            Pixels: <strong className="text-rose-400">{drawnCount}</strong> / {totalPixels}
          </span>
          {cursorPos && (
            <span className="text-slate-500">
              [X: {cursorPos.x}, Y: {cursorPos.y}]
            </span>
          )}
        </div>

        {/* Current Active Color Preview */}
        <div className="flex items-center gap-2">
          <span className="text-slate-500">Color:</span>
          <div 
            className="w-5 h-5 rounded border border-white/40 shadow-sm"
            style={{ backgroundColor: currentColor }}
          />
          <span className="text-[11px] uppercase tracking-wider">{currentColor}</span>
        </div>
      </div>

      {/* Palette Selector Bar */}
      {showControls && (
        <div className="mt-3 p-2.5 bg-slate-900/90 border border-slate-800 rounded-lg space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-pixel text-slate-400 text-[10px]">
              {selectedPalette.name}
            </span>
            <select
              value={selectedPalette.id}
              onChange={(e) => {
                const pal = RETRO_PALETTES.find((p) => p.id === e.target.value);
                if (pal) setSelectedPalette(pal);
              }}
              className="text-xs bg-slate-800 text-slate-300 border border-slate-700 rounded px-2 py-0.5 cursor-pointer outline-none focus:border-rose-500"
            >
              {RETRO_PALETTES.map((pal) => (
                <option key={pal.id} value={pal.id}>
                  {pal.name}
                </option>
              ))}
            </select>
          </div>

          {/* Color Swatches Grid */}
          <div className="flex flex-wrap gap-1.5 items-center">
            {selectedPalette.colors.map((color, idx) => (
              <button
                key={`${color}-${idx}`}
                type="button"
                onClick={() => {
                  setCurrentColor(color);
                  sound.playPixelPlace();
                }}
                style={{ backgroundColor: color }}
                className={`w-6 h-6 rounded cursor-pointer transition-transform transform active:scale-90 ${
                  currentColor.toLowerCase() === color.toLowerCase()
                    ? 'ring-2 ring-white ring-offset-2 ring-offset-slate-900 scale-110 shadow-md'
                    : 'hover:scale-105 border border-white/10'
                }`}
                title={color}
              />
            ))}

            {/* Custom Color Input */}
            <div className="relative flex items-center ml-2 border-l border-slate-800 pl-2">
              <label 
                title="Custom Hex Picker"
                className="w-6 h-6 rounded cursor-pointer overflow-hidden border border-slate-700 hover:border-slate-500 flex items-center justify-center bg-gradient-to-tr from-rose-500 via-yellow-500 to-cyan-500"
              >
                <input
                  type="color"
                  value={customColor}
                  onChange={(e) => {
                    setCustomColor(e.target.value);
                    setCurrentColor(e.target.value);
                  }}
                  className="opacity-0 w-0 h-0 cursor-pointer"
                />
              </label>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
