import React, { useState } from 'react';
import { DuelRoom } from '../types/game';
import { getEloTier, calculateEloChange } from '../utils/elo';
import { sound } from '../utils/audio';
import confetti from 'canvas-confetti';
import { 
  Vote, 
  Sparkles, 
  Trophy, 
  CheckCircle2, 
  TrendingUp, 
  ChevronRight, 
  Flame, 
  Layers, 
  Download,
  Share2
} from 'lucide-react';
import { exportGridToDataUrl } from '../utils/palettes';

interface VotingArenaProps {
  duels: DuelRoom[];
  voterId: string;
  onCastVote: (duelId: string, votedFor: 'player1' | 'player2') => void;
  selectedDuelId?: string;
  onSelectDuel?: (duelId: string) => void;
}

export const VotingArena: React.FC<VotingArenaProps> = ({
  duels,
  voterId,
  onCastVote,
  selectedDuelId,
  onSelectDuel,
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [internalSelectedId, setInternalSelectedId] = useState<string>(
    selectedDuelId || (duels[0]?.id ?? '')
  );

  const currentDuelId = selectedDuelId || internalSelectedId;
  const currentDuel = duels.find((d) => d.id === currentDuelId) || duels[0];

  const hasVoted = currentDuel?.votedUserIds.includes(voterId) || false;
  const totalVotes = currentDuel ? currentDuel.player1Votes + currentDuel.player2Votes : 0;
  const p1Percent = totalVotes > 0 ? Math.round((currentDuel.player1Votes / totalVotes) * 100) : 50;
  const p2Percent = 100 - p1Percent;

  const categories = ['All', 'Creatures', 'Characters', 'Items & Food', 'Cyberpunk', 'Scenery', 'Fantasy'];

  const filteredDuels = duels.filter((d) => {
    if (activeCategory === 'All') return true;
    return d.category === activeCategory;
  });

  const handleVote = (choice: 'player1' | 'player2') => {
    if (!currentDuel || hasVoted) return;

    sound.playVote();
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#f43f5e', '#22d3ee', '#facc15', '#a855f7'],
    });

    onCastVote(currentDuel.id, choice);
  };

  const handleNextDuel = () => {
    const currentIndex = duels.findIndex((d) => d.id === currentDuel?.id);
    const nextDuel = duels[(currentIndex + 1) % duels.length];
    if (nextDuel) {
      if (onSelectDuel) onSelectDuel(nextDuel.id);
      setInternalSelectedId(nextDuel.id);
      sound.playClick();
    }
  };

  if (!currentDuel) {
    return (
      <div className="max-w-4xl mx-auto py-16 px-4 text-center space-y-4">
        <Vote className="w-16 h-16 text-slate-600 mx-auto animate-pulse" />
        <h2 className="text-xl font-bold font-pixel text-slate-300">NO ACTIVE DUELS IN VOTING</h2>
        <p className="text-sm text-slate-400 font-mono">
          Queue up for a 1v1 battle to submit the next pixel masterpiece to the community!
        </p>
      </div>
    );
  }

  // Pre-calculate live ELO changes based on current votes
  const score1 = currentDuel.player1Votes > currentDuel.player2Votes ? 1 : currentDuel.player1Votes === currentDuel.player2Votes ? 0.5 : 0;
  const eloForecast = calculateEloChange(currentDuel.player1.elo, currentDuel.player2.elo, score1);

  const p1Tier = getEloTier(currentDuel.player1.elo);
  const p2Tier = getEloTier(currentDuel.player2.elo);

  return (
    <div className="max-w-7xl mx-auto px-2 sm:px-4 py-4 space-y-6">
      {/* Colosseum Header */}
      <div className="p-4 sm:p-6 bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border-2 border-indigo-900/60 rounded-2xl shadow-xl text-center relative overflow-hidden">
        <div className="flex items-center justify-center gap-2 mb-1">
          <Vote className="w-5 h-5 text-cyan-400" />
          <span className="font-pixel text-xs text-cyan-400 tracking-wider">
            COMMUNITY COLOSSEUM
          </span>
        </div>

        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-wide">
          Which pixel art best captures the prompt?
        </h1>

        <div className="inline-flex items-center gap-2 mt-2 px-4 py-1.5 bg-slate-950/80 border border-indigo-700/50 rounded-full">
          <span className="text-xs font-mono text-slate-400 uppercase">PROMPT:</span>
          <span className="font-bold text-amber-300 text-sm sm:text-base">"{currentDuel.prompt}"</span>
          <span className="text-[10px] px-2 py-0.5 rounded bg-indigo-900/60 text-indigo-300 font-mono">
            {currentDuel.category}
          </span>
        </div>

        {/* Voting Rules Info */}
        <p className="text-xs font-mono text-slate-400 mt-2 max-w-xl mx-auto">
          {!hasVoted 
            ? 'Blind Voting Mode: Artist identities are hidden until your vote is cast to guarantee unbiased judging!' 
            : 'Vote counted! Artist identities, vote breakdown, and ELO rating adjustments revealed below.'}
        </p>
      </div>

      {/* Main Duel Stage: 2-Columns Side by Side Comparison */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch">
        {/* Creation Alpha (Player 1) */}
        <div className={`flex flex-col justify-between p-5 bg-slate-900/90 border-2 rounded-2xl shadow-xl transition-all ${
          hasVoted && currentDuel.player1Votes > currentDuel.player2Votes 
            ? 'border-amber-400/80 bg-gradient-to-b from-slate-900 to-amber-950/20' 
            : 'border-slate-800'
        }`}>
          {/* Top Identifier */}
          <div className="flex items-center justify-between mb-4">
            <span className="px-3 py-1 bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded-lg text-xs font-pixel">
              CREATION ALPHA
            </span>

            {hasVoted && (
              <div className="flex items-center gap-2">
                <span className="text-xl">{currentDuel.player1.avatar}</span>
                <div className="text-right">
                  <div className="text-xs font-bold text-white flex items-center gap-1 justify-end">
                    {currentDuel.player1.name}
                    <span title={p1Tier.title}>{p1Tier.badge}</span>
                  </div>
                  <div className="text-[11px] font-mono text-slate-400">
                    {currentDuel.player1.elo} ELO
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Canvas Display */}
          <div className="relative aspect-square max-w-[280px] sm:max-w-[320px] mx-auto w-full p-2 bg-slate-950 border-2 border-slate-800 rounded-xl overflow-hidden shadow-2xl flex items-center justify-center">
            <div
              className="grid aspect-square w-full rounded pixel-art"
              style={{
                gridTemplateColumns: `repeat(${currentDuel.gridSize}, minmax(0, 1fr))`,
              }}
            >
              {currentDuel.player1Grid.map((row, r) =>
                row.map((color, c) => (
                  <div
                    key={`p1-${r}-${c}`}
                    style={{
                      backgroundColor: color && color !== 'transparent' ? color : '#090d16',
                    }}
                    className="w-full h-full"
                  />
                ))
              )}
            </div>
          </div>

          {/* Post-Vote Info & Vote Button */}
          <div className="mt-5 space-y-3">
            {hasVoted ? (
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
                <div className="flex justify-between items-center text-xs font-mono">
                  <span className="text-slate-300 font-bold">Community Support:</span>
                  <span className="text-rose-400 font-pixel text-sm">{p1Percent}% ({currentDuel.player1Votes} votes)</span>
                </div>
                <div className="w-full h-2.5 bg-slate-900 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-rose-500 transition-all duration-500" 
                    style={{ width: `${p1Percent}%` }} 
                  />
                </div>
                <div className="flex items-center justify-between text-xs font-mono pt-1 text-slate-400 border-t border-slate-900">
                  <span>ELO Adjustment:</span>
                  <span className={`font-bold ${eloForecast.changeA >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {eloForecast.changeA >= 0 ? `+${eloForecast.changeA}` : eloForecast.changeA} ELO
                  </span>
                </div>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => handleVote('player1')}
                className="w-full py-3.5 px-4 bg-gradient-to-r from-rose-500 to-pink-600 hover:from-rose-600 hover:to-pink-700 text-white font-pixel text-xs sm:text-sm uppercase tracking-wider rounded-xl shadow-lg shadow-rose-500/25 transition-all transform hover:-translate-y-0.5 active:translate-y-0 cursor-pointer"
              >
                VOTE FOR CREATION ALPHA
              </button>
            )}
          </div>
        </div>

        {/* Creation Beta (Player 2) */}
        <div className={`flex flex-col justify-between p-5 bg-slate-900/90 border-2 rounded-2xl shadow-xl transition-all ${
          hasVoted && currentDuel.player2Votes > currentDuel.player1Votes 
            ? 'border-amber-400/80 bg-gradient-to-b from-slate-900 to-amber-950/20' 
            : 'border-slate-800'
        }`}>
          {/* Top Identifier */}
          <div className="flex items-center justify-between mb-4">
            <span className="px-3 py-1 bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 rounded-lg text-xs font-pixel">
              CREATION BETA
            </span>

            {hasVoted && (
              <div className="flex items-center gap-2">
                <span className="text-xl">{currentDuel.player2.avatar}</span>
                <div className="text-right">
                  <div className="text-xs font-bold text-white flex items-center gap-1 justify-end">
                    {currentDuel.player2.name}
                    <span title={p2Tier.title}>{p2Tier.badge}</span>
                  </div>
                  <div className="text-[11px] font-mono text-slate-400">
                    {currentDuel.player2.elo} ELO
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Canvas Display */}
          <div className="relative aspect-square max-w-[280px] sm:max-w-[320px] mx-auto w-full p-2 bg-slate-950 border-2 border-slate-800 rounded-xl overflow-hidden shadow-2xl flex items-center justify-center">
            <div
              className="grid aspect-square w-full rounded pixel-art"
              style={{
                gridTemplateColumns: `repeat(${currentDuel.gridSize}, minmax(0, 1fr))`,
              }}
            >
              {currentDuel.player2Grid.map((row, r) =>
                row.map((color, c) => (
                  <div
                    key={`p2-${r}-${c}`}
                    style={{
                      backgroundColor: color && color !== 'transparent' ? color : '#090d16',
                    }}
                    className="w-full h-full"
                  />
                ))
              )}
            </div>
          </div>

          {/* Post-Vote Info & Vote Button */}
          <div className="mt-5 space-y-3">
            {hasVoted ? (
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
                <div className="flex justify-between items-center text-xs font-mono">
                  <span className="text-slate-300 font-bold">Community Support:</span>
                  <span className="text-cyan-400 font-pixel text-sm">{p2Percent}% ({currentDuel.player2Votes} votes)</span>
                </div>
                <div className="w-full h-2.5 bg-slate-900 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-cyan-500 transition-all duration-500" 
                    style={{ width: `${p2Percent}%` }} 
                  />
                </div>
                <div className="flex items-center justify-between text-xs font-mono pt-1 text-slate-400 border-t border-slate-900">
                  <span>ELO Adjustment:</span>
                  <span className={`font-bold ${eloForecast.changeB >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {eloForecast.changeB >= 0 ? `+${eloForecast.changeB}` : eloForecast.changeB} ELO
                  </span>
                </div>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => handleVote('player2')}
                className="w-full py-3.5 px-4 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-pixel text-xs sm:text-sm uppercase tracking-wider rounded-xl shadow-lg shadow-cyan-500/25 transition-all transform hover:-translate-y-0.5 active:translate-y-0 cursor-pointer"
              >
                VOTE FOR CREATION BETA
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Navigation / Next Duel Banner */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-4 bg-slate-900 border border-slate-800 rounded-xl">
        <div className="flex items-center gap-2">
          <Trophy className="w-5 h-5 text-amber-400" />
          <span className="text-xs font-mono text-slate-300">
            Total Community Votes Cast: <strong className="text-white font-bold">{totalVotes}</strong>
          </span>
        </div>

        <button
          type="button"
          onClick={handleNextDuel}
          className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-lg text-xs font-mono cursor-pointer transition-colors"
        >
          <span>Judge Next Duel</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Category Filter Tabs & Duels Feed */}
      <div className="space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <h2 className="text-lg font-bold text-white font-pixel flex items-center gap-2">
            <Layers className="w-5 h-5 text-rose-500" />
            Active Voting Queue
          </h2>

          <div className="flex flex-wrap gap-1">
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => { setActiveCategory(cat); sound.playClick(); }}
                className={`px-2.5 py-1 rounded-lg text-xs font-mono cursor-pointer transition-all ${
                  activeCategory === cat 
                    ? 'bg-rose-500 text-white font-bold' 
                    : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Duel Grid Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {filteredDuels.map((duel) => {
            const isSelected = duel.id === currentDuel.id;
            const hasVotedDuel = duel.votedUserIds.includes(voterId);
            const votes = duel.player1Votes + duel.player2Votes;

            return (
              <div
                key={duel.id}
                onClick={() => {
                  if (onSelectDuel) onSelectDuel(duel.id);
                  setInternalSelectedId(duel.id);
                  sound.playClick();
                }}
                className={`p-3.5 bg-slate-900/90 border rounded-xl cursor-pointer transition-all hover:scale-[1.02] flex flex-col justify-between ${
                  isSelected 
                    ? 'border-cyan-400 ring-2 ring-cyan-500/20 shadow-lg shadow-cyan-500/10' 
                    : 'border-slate-800 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 mb-2">
                    <span className="px-1.5 py-0.5 rounded bg-slate-800 text-cyan-300">
                      {duel.category}
                    </span>
                    {hasVotedDuel ? (
                      <span className="text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Voted
                      </span>
                    ) : (
                      <span className="text-amber-400">Needs Vote</span>
                    )}
                  </div>

                  <h3 className="font-bold text-sm text-slate-200 line-clamp-1 mb-2">
                    "{duel.prompt}"
                  </h3>

                  {/* Dual Thumbnail Preview */}
                  <div className="grid grid-cols-2 gap-2 my-2 bg-slate-950 p-2 rounded-lg border border-slate-800/80">
                    <div 
                      className="grid aspect-square rounded overflow-hidden"
                      style={{ gridTemplateColumns: `repeat(${duel.gridSize}, minmax(0, 1fr))` }}
                    >
                      {duel.player1Grid.map((row, r) =>
                        row.map((c, idx) => (
                          <div
                            key={`thumb1-${r}-${idx}`}
                            style={{ backgroundColor: c && c !== 'transparent' ? c : '#0a0f1d' }}
                            className="w-full h-full"
                          />
                        ))
                      )}
                    </div>

                    <div 
                      className="grid aspect-square rounded overflow-hidden"
                      style={{ gridTemplateColumns: `repeat(${duel.gridSize}, minmax(0, 1fr))` }}
                    >
                      {duel.player2Grid.map((row, r) =>
                        row.map((c, idx) => (
                          <div
                            key={`thumb2-${r}-${idx}`}
                            style={{ backgroundColor: c && c !== 'transparent' ? c : '#0a0f1d' }}
                            className="w-full h-full"
                          />
                        ))
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs font-mono text-slate-400 mt-2 pt-2 border-t border-slate-800">
                  <span>{votes} votes cast</span>
                  <span className="text-rose-400 text-[11px] font-semibold">Judge Now →</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
