export type PixelColor = string; // hex color e.g. '#ffffff' or 'transparent'
export type PixelGrid = PixelColor[][]; // [row][col] (y, x)

export type ToolType = 
  | 'pencil' 
  | 'eraser' 
  | 'bucket' 
  | 'picker' 
  | 'line' 
  | 'rect' 
  | 'dither';

export interface Palette {
  id: string;
  name: string;
  colors: string[];
}

export interface Player {
  id: string;
  name: string;
  avatar: string; // pixel avatar icon key or data
  elo: number;
  matchesPlayed: number;
  wins: number;
  losses: number;
  draws: number;
  currentStreak: number;
  bestStreak: number;
  isReady?: boolean;
}

export type DuelPhase = 
  | 'waiting'      // waiting for opponent
  | 'countdown'    // 3, 2, 1 countdown
  | 'drawing'      // both players drawing simultaneously
  | 'voting'       // community voting period
  | 'finished';    // results finalized & ELO applied

export interface DuelRoom {
  id: string;
  prompt: string;
  category: string;
  gridSize: number; // 16 or 24 or 32
  durationSeconds: number;
  timeRemaining: number;
  phase: DuelPhase;
  createdAt: number;
  player1: Player;
  player2: Player;
  player1Grid: PixelGrid;
  player2Grid: PixelGrid;
  player1PixelCount: number;
  player2PixelCount: number;
  player1Votes: number;
  player2Votes: number;
  votedUserIds: string[];
  winnerId?: string | 'draw';
  player1EloChange?: number;
  player2EloChange?: number;
  isBotOpponent?: boolean;
}

export interface VoteSubmission {
  duelId: string;
  voterId: string;
  votedFor: 'player1' | 'player2';
}

export interface ChatTaunt {
  id: string;
  senderName: string;
  senderId: string;
  text: string;
  timestamp: number;
}

export interface EloTierInfo {
  tier: 'Bronze' | 'Silver' | 'Gold' | 'Platinum' | 'Diamond' | 'Master' | 'Grandmaster';
  minElo: number;
  maxElo: number;
  badge: string;
  color: string;
  borderClass: string;
  bgClass: string;
  title: string;
}

export interface HistoricalMatch {
  id: string;
  date: string;
  prompt: string;
  opponentName: string;
  opponentElo: number;
  result: 'win' | 'loss' | 'draw';
  eloChange: number;
  myGrid: PixelGrid;
  opponentGrid: PixelGrid;
  myVotes: number;
  opponentVotes: number;
}
