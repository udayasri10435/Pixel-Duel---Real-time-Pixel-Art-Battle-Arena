import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Player, DuelRoom, PixelGrid, HistoricalMatch } from './types/game';
import { Navbar } from './components/Navbar';
import { DuelArena } from './components/DuelArena';
import { VotingArena } from './components/VotingArena';
import { LeaderboardView } from './components/LeaderboardView';
import { ProfileView } from './components/ProfileView';
import { LocalDuelView } from './components/LocalDuelView';
import { FreeDrawView } from './components/FreeDrawView';
import { MatchmakingModal } from './components/MatchmakingModal';
import { getEloTier } from './utils/elo';
import { PRESET_VOTING_DUELS, PRESET_HISTORICAL_MATCHES } from './utils/presetDuels';
import { countDrawnPixels } from './utils/palettes';
import { sound } from './utils/audio';
import { 
  Swords, 
  Vote, 
  Trophy, 
  Bot, 
  Users, 
  Sparkles, 
  Flame, 
  ArrowRight,
  ShieldCheck,
  Zap,
  Palette
} from 'lucide-react';

const LOCAL_STORAGE_KEY_PLAYER = 'pixel_duel_player_profile';
const LOCAL_STORAGE_KEY_MATCHES = 'pixel_duel_match_history';

export default function App() {
  // Initialize player state
  const [player, setPlayer] = useState<Player>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY_PLAYER);
      if (saved) return JSON.parse(saved);
    } catch {
      // Fallback
    }
    return {
      id: `p-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      name: 'PixelChallenger',
      avatar: '🎨',
      elo: 1200,
      matchesPlayed: 0,
      wins: 0,
      losses: 0,
      draws: 0,
      currentStreak: 0,
      bestStreak: 0,
    };
  });

  // Navigation tab
  const [currentTab, setCurrentTab] = useState<
    'arena' | 'voting' | 'leaderboard' | 'local' | 'freedraw' | 'profile'
  >('arena');

  // Active Live Duel
  const [activeRoom, setActiveRoom] = useState<DuelRoom | null>(null);
  const [playerRole, setPlayerRole] = useState<'player1' | 'player2'>('player1');
  const [incomingTaunts, setIncomingTaunts] = useState<{ senderName: string; text: string; id: string }[]>([]);

  // Queue state
  const [inQueue, setInQueue] = useState<boolean>(false);

  // Community voting duels
  const [votingDuels, setVotingDuels] = useState<DuelRoom[]>(PRESET_VOTING_DUELS);
  const [selectedVotingDuelId, setSelectedVotingDuelId] = useState<string | undefined>(undefined);

  // Leaderboard data
  const [leaderboard, setLeaderboard] = useState<Player[]>([]);

  // Match History
  const [matches, setMatches] = useState<HistoricalMatch[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY_MATCHES);
      if (saved) return JSON.parse(saved);
    } catch {
      // Fallback
    }
    return PRESET_HISTORICAL_MATCHES;
  });

  // Sound toggle
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  // Connection
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [onlineCount, setOnlineCount] = useState<number>(1);
  const socketRef = useRef<WebSocket | null>(null);

  // Save player state on change
  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY_PLAYER, JSON.stringify(player));
    } catch {
      // Ignore
    }
  }, [player]);

  // Save matches on change
  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY_MATCHES, JSON.stringify(matches));
    } catch {
      // Ignore
    }
  }, [matches]);

  // Sound toggle handler
  const handleToggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    sound.enabled = next;
  };

  // Fetch initial leaderboard from REST
  useEffect(() => {
    fetch('/api/leaderboard')
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) setLeaderboard(data);
      })
      .catch(() => {
        // Fallback
      });
  }, []);

  // WebSocket Connection Management
  useEffect(() => {
    let reconnectTimeout: NodeJS.Timeout;

    const connectWebSocket = () => {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}`;

      try {
        const ws = new WebSocket(wsUrl);
        socketRef.current = ws;

        ws.onopen = () => {
          setIsConnected(true);
          // Send authentication & player profile
          ws.send(JSON.stringify({
            type: 'AUTH',
            player,
          }));
        };

        ws.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data);

            switch (data.type) {
              case 'AUTH_SUCCESS': {
                setOnlineCount(data.onlineCount || 1);
                break;
              }

              case 'COMMUNITY_DUELS_SYNC': {
                if (Array.isArray(data.duels) && data.duels.length > 0) {
                  setVotingDuels(data.duels);
                }
                break;
              }

              case 'QUEUE_STATUS': {
                setInQueue(data.inQueue);
                break;
              }

              case 'MATCH_FOUND': {
                setInQueue(false);
                setActiveRoom(data.room);
                setPlayerRole(data.playerRole);
                setCurrentTab('arena');
                sound.playMatchStart();
                break;
              }

              case 'TIMER_TICK': {
                setActiveRoom((prev) => prev ? { ...prev, timeRemaining: data.timeRemaining } : null);
                break;
              }

              case 'PHASE_CHANGE': {
                setActiveRoom((prev) => {
                  if (!prev) return null;
                  const updated = { ...prev, phase: data.phase };
                  if (data.room) return data.room;
                  return updated;
                });
                break;
              }

              case 'OPPONENT_UPDATE': {
                setActiveRoom((prev) => {
                  if (!prev) return null;
                  if (data.playerRole === 'player1') {
                    return { ...prev, player1PixelCount: data.pixelCount };
                  } else {
                    return { ...prev, player2PixelCount: data.pixelCount };
                  }
                });
                break;
              }

              case 'VOTE_UPDATE': {
                setVotingDuels((prev) =>
                  prev.map((d) =>
                    d.id === data.duelId
                      ? {
                          ...d,
                          player1Votes: data.player1Votes,
                          player2Votes: data.player2Votes,
                          player1EloChange: data.player1EloChange,
                          player2EloChange: data.player2EloChange,
                        }
                      : d
                  )
                );
                setActiveRoom((prev) =>
                  prev && prev.id === data.duelId
                    ? {
                        ...prev,
                        player1Votes: data.player1Votes,
                        player2Votes: data.player2Votes,
                      }
                    : prev
                );
                break;
              }

              case 'NEW_COMMUNITY_DUEL': {
                setVotingDuels((prev) => [data.duel, ...prev.filter((d) => d.id !== data.duel.id)]);
                break;
              }

              case 'TAUNT_RECEIVED': {
                setIncomingTaunts((prev) => [
                  ...prev,
                  { senderName: data.senderName, text: data.text, id: `${Date.now()}-${Math.random()}` },
                ]);
                break;
              }

              case 'DUEL_FINALIZED': {
                const finalDuel: DuelRoom = data.duel;
                // If I was in this duel, update my stats
                if (finalDuel.player1.id === player.id) {
                  setPlayer(finalDuel.player1);
                } else if (finalDuel.player2.id === player.id) {
                  setPlayer(finalDuel.player2);
                }
                break;
              }
            }
          } catch (e) {
            console.error('Error handling WebSocket message:', e);
          }
        };

        ws.onclose = () => {
          setIsConnected(false);
          // Try reconnecting after 3 seconds
          reconnectTimeout = setTimeout(connectWebSocket, 3000);
        };

        ws.onerror = () => {
          setIsConnected(false);
        };
      } catch {
        setIsConnected(false);
        reconnectTimeout = setTimeout(connectWebSocket, 3000);
      }
    };

    connectWebSocket();

    return () => {
      clearTimeout(reconnectTimeout);
      if (socketRef.current) socketRef.current.close();
    };
  }, []);

  // Update canvas during duel
  const handleGridChange = (newGrid: PixelGrid) => {
    if (!activeRoom) return;

    const count = countDrawnPixels(newGrid);

    setActiveRoom((prev) => {
      if (!prev) return null;
      if (playerRole === 'player1') {
        return { ...prev, player1Grid: newGrid, player1PixelCount: count };
      } else {
        return { ...prev, player2Grid: newGrid, player2PixelCount: count };
      }
    });

    // Send delta/grid update to server
    if (socketRef.current?.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({
        type: 'CANVAS_UPDATE',
        roomId: activeRoom.id,
        playerRole,
        grid: newGrid,
        pixelCount: count,
      }));
    }
  };

  // Start matchmaking queue
  const handleQueueJoin = () => {
    setInQueue(true);
    sound.playClick();
    if (socketRef.current?.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({ type: 'QUEUE_JOIN' }));
    }
  };

  // Cancel matchmaking queue
  const handleQueueLeave = () => {
    setInQueue(false);
    sound.playClick();
    if (socketRef.current?.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({ type: 'QUEUE_LEAVE' }));
    }
  };

  // Start Instant Bot Match
  const handleStartBotDuel = () => {
    setInQueue(false);
    sound.playMatchStart();
    if (socketRef.current?.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({ type: 'START_BOT_DUEL' }));
    }
  };

  // Send Taunt
  const handleSendTaunt = (text: string) => {
    if (!activeRoom) return;
    if (socketRef.current?.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({
        type: 'SEND_TAUNT',
        roomId: activeRoom.id,
        text,
      }));
    }
  };

  // Cast vote on a duel
  const handleCastVote = (duelId: string, votedFor: 'player1' | 'player2') => {
    // Send via WebSocket or REST
    if (socketRef.current?.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({
        type: 'CAST_VOTE',
        duelId,
        voterId: player.id,
        votedFor,
      }));
    } else {
      // Fallback REST call
      fetch(`/api/duels/${duelId}/vote`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ voterId: player.id, votedFor }),
      }).catch(console.error);
    }

    // Local optimistic update
    setVotingDuels((prev) =>
      prev.map((d) => {
        if (d.id === duelId) {
          const updated = { ...d, votedUserIds: [...d.votedUserIds, player.id] };
          if (votedFor === 'player1') updated.player1Votes++;
          else updated.player2Votes++;
          return updated;
        }
        return d;
      })
    );
  };

  // Jump from finished duel to voting arena
  const handleGoToVoting = (duelId: string) => {
    // Save match to historical matches
    if (activeRoom) {
      const isP1 = playerRole === 'player1';
      const myGrid = isP1 ? activeRoom.player1Grid : activeRoom.player2Grid;
      const oppGrid = isP1 ? activeRoom.player2Grid : activeRoom.player1Grid;
      const opponent = isP1 ? activeRoom.player2 : activeRoom.player1;

      const newMatch: HistoricalMatch = {
        id: `match-${Date.now()}`,
        date: 'Just now',
        prompt: activeRoom.prompt,
        opponentName: opponent.name,
        opponentElo: opponent.elo,
        result: 'win', // pending community votes
        eloChange: 16,
        myGrid,
        opponentGrid: oppGrid,
        myVotes: 1,
        opponentVotes: 0,
      };

      setMatches((prev) => [newMatch, ...prev]);
    }

    setActiveRoom(null);
    setSelectedVotingDuelId(duelId);
    setCurrentTab('voting');
  };

  const myTier = getEloTier(player.elo);

  return (
    <div className="min-h-screen bg-[#090d16] text-slate-100 flex flex-col font-sans selection:bg-rose-500 selection:text-white">
      {/* Top Navigation Bar */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        player={player}
        soundEnabled={soundEnabled}
        onToggleSound={handleToggleSound}
        activeVotingCount={votingDuels.length}
        onlineCount={onlineCount}
        isConnected={isConnected}
      />

      {/* Matchmaking Queue Modal */}
      {inQueue && (
        <MatchmakingModal
          player={player}
          onCancel={handleQueueLeave}
          onStartBotMatch={handleStartBotDuel}
        />
      )}

      {/* Main Content Area */}
      <main className="flex-1 pb-16">
        {/* TAB 1: 1v1 ARENA */}
        {currentTab === 'arena' && (
          <>
            {activeRoom ? (
              <DuelArena
                room={activeRoom}
                playerRole={playerRole}
                onGridChange={handleGridChange}
                onSendTaunt={handleSendTaunt}
                incomingTaunts={incomingTaunts}
                onGoToVoting={handleGoToVoting}
              />
            ) : (
              /* Arena Home Hub: Ready to Queue / Battle */
              <div className="max-w-6xl mx-auto px-4 py-8 space-y-10">
                {/* Hero Duel Arena Banner */}
                <div className="relative p-6 sm:p-10 bg-gradient-to-br from-slate-900 via-indigo-950/40 to-slate-900 border-2 border-rose-500/30 rounded-3xl shadow-2xl overflow-hidden text-center">
                  <div className="absolute top-0 right-1/4 w-96 h-96 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" />
                  <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

                  <div className="relative space-y-4 max-w-2xl mx-auto">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/10 border border-rose-500/30 text-rose-400 font-mono text-xs">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Season 1 Competitive Arena</span>
                    </div>

                    <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
                      Same Prompt.
                      <span className="block font-pixel text-2xl sm:text-4xl mt-2 bg-gradient-to-r from-rose-400 via-amber-300 to-cyan-400 bg-clip-text text-transparent">
                        60 SECONDS. ONE WINNER.
                      </span>
                    </h1>

                    <p className="text-sm sm:text-base text-slate-300 font-mono">
                      Two artists receive the exact same pixel-art prompt and draw simultaneously. 
                      When the clock hits zero, the community votes blindly to decide who claims the ELO rating!
                    </p>

                    {/* Big Launch Action Buttons */}
                    <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
                      <button
                        type="button"
                        onClick={handleQueueJoin}
                        className="w-full sm:w-auto flex items-center justify-center gap-3 py-4 px-8 bg-gradient-to-r from-rose-500 via-pink-600 to-rose-600 hover:from-rose-600 hover:to-rose-700 text-white font-pixel text-sm uppercase tracking-wider rounded-2xl shadow-xl shadow-rose-500/30 transform hover:-translate-y-1 transition-all cursor-pointer"
                      >
                        <Swords className="w-5 h-5" />
                        <span>Find 1v1 Duel</span>
                      </button>

                      <button
                        type="button"
                        onClick={handleStartBotDuel}
                        className="w-full sm:w-auto flex items-center justify-center gap-2 py-4 px-6 bg-slate-900 hover:bg-slate-800 text-slate-200 hover:text-white font-pixel text-xs uppercase tracking-wider rounded-2xl border border-slate-700 hover:border-slate-600 transition-all cursor-pointer"
                      >
                        <Bot className="w-4 h-4 text-cyan-400" />
                        <span>Instant Bot Duel</span>
                      </button>
                    </div>

                    {/* Player Standings Pill */}
                    <div className="inline-flex items-center gap-3 pt-3 text-xs font-mono text-slate-400">
                      <span>Rating: <strong className="text-amber-400">{player.elo} ELO</strong></span>
                      <span>•</span>
                      <span>Tier: <strong className="text-white">{myTier.badge} {myTier.tier}</strong></span>
                      <span>•</span>
                      <span>Streak: <strong className="text-orange-400">{player.currentStreak} 🔥</strong></span>
                    </div>
                  </div>
                </div>

                {/* Quick Game Modes Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                  {/* Mode 1: Community Colosseum */}
                  <div 
                    onClick={() => { setCurrentTab('voting'); sound.playClick(); }}
                    className="p-6 bg-slate-900/90 border border-slate-800 hover:border-cyan-500/50 rounded-2xl shadow-lg cursor-pointer transition-all hover:-translate-y-1 group flex flex-col justify-between"
                  >
                    <div>
                      <div className="w-12 h-12 rounded-xl bg-cyan-950 border border-cyan-800 flex items-center justify-center text-cyan-400 mb-4 group-hover:scale-110 transition-transform">
                        <Vote className="w-6 h-6" />
                      </div>
                      <h3 className="font-pixel text-sm text-white mb-1">Voting Arena</h3>
                      <p className="text-xs font-mono text-slate-400">
                        Blindly judge side-by-side artworks from active duels. Your vote directly impacts players' ELO!
                      </p>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs font-mono text-cyan-400 mt-4 font-bold">
                      <span>Judge Duels ({votingDuels.length} active)</span>
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>

                  {/* Mode 2: Local 2-Player Pass & Play */}
                  <div 
                    onClick={() => { setCurrentTab('local'); sound.playClick(); }}
                    className="p-6 bg-slate-900/90 border border-slate-800 hover:border-purple-500/50 rounded-2xl shadow-lg cursor-pointer transition-all hover:-translate-y-1 group flex flex-col justify-between"
                  >
                    <div>
                      <div className="w-12 h-12 rounded-xl bg-purple-950 border border-purple-800 flex items-center justify-center text-purple-400 mb-4 group-hover:scale-110 transition-transform">
                        <Users className="w-6 h-6" />
                      </div>
                      <h3 className="font-pixel text-sm text-white mb-1">Local Pass & Play</h3>
                      <p className="text-xs font-mono text-slate-400">
                        Two artists on the same screen! Draw simultaneously on split canvases under a shared timer.
                      </p>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs font-mono text-purple-400 mt-4 font-bold">
                      <span>Split-Screen Duel</span>
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>

                  {/* Mode 3: Practice Sandbox */}
                  <div 
                    onClick={() => { setCurrentTab('freedraw'); sound.playClick(); }}
                    className="p-6 bg-slate-900/90 border border-slate-800 hover:border-emerald-500/50 rounded-2xl shadow-lg cursor-pointer transition-all hover:-translate-y-1 group flex flex-col justify-between"
                  >
                    <div>
                      <div className="w-12 h-12 rounded-xl bg-emerald-950 border border-emerald-800 flex items-center justify-center text-emerald-400 mb-4 group-hover:scale-110 transition-transform">
                        <Palette className="w-6 h-6" />
                      </div>
                      <h3 className="font-pixel text-sm text-white mb-1">Practice Studio</h3>
                      <p className="text-xs font-mono text-slate-400">
                        Warm up your pixel-art reflexes with unlimited time, curated palettes, and random prompts.
                      </p>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs font-mono text-emerald-400 mt-4 font-bold">
                      <span>Free Sandbox</span>
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                </div>

                {/* Community Voting Spotlight Carousel */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h2 className="text-base font-bold text-white font-pixel flex items-center gap-2">
                      <Vote className="w-4 h-4 text-cyan-400" />
                      Featured Battles Awaiting Your Vote
                    </h2>
                    <button
                      type="button"
                      onClick={() => setCurrentTab('voting')}
                      className="text-xs font-mono text-cyan-400 hover:text-cyan-300"
                    >
                      View All ({votingDuels.length}) →
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {votingDuels.slice(0, 4).map((duel) => (
                      <div
                        key={duel.id}
                        onClick={() => {
                          setSelectedVotingDuelId(duel.id);
                          setCurrentTab('voting');
                          sound.playClick();
                        }}
                        className="p-3 bg-slate-900/90 border border-slate-800 hover:border-slate-700 rounded-xl cursor-pointer hover:scale-[1.02] transition-all space-y-2"
                      >
                        <div className="flex justify-between items-center text-[10px] font-mono text-slate-400">
                          <span className="text-cyan-300">{duel.category}</span>
                          <span>{duel.player1Votes + duel.player2Votes} votes</span>
                        </div>
                        <h4 className="font-bold text-xs text-white line-clamp-1">
                          "{duel.prompt}"
                        </h4>
                        <div className="grid grid-cols-2 gap-1.5 bg-slate-950 p-1.5 rounded-lg border border-slate-800/60">
                          <div 
                            className="grid aspect-square rounded overflow-hidden"
                            style={{ gridTemplateColumns: `repeat(${duel.gridSize}, minmax(0, 1fr))` }}
                          >
                            {duel.player1Grid.map((row, r) =>
                              row.map((c, idx) => (
                                <div
                                  key={`thumb1-${r}-${idx}`}
                                  style={{ backgroundColor: c && c !== 'transparent' ? c : '#0a0f1d' }}
                                  className="w-full h-full"
                                />
                              ))
                            )}
                          </div>
                          <div 
                            className="grid aspect-square rounded overflow-hidden"
                            style={{ gridTemplateColumns: `repeat(${duel.gridSize}, minmax(0, 1fr))` }}
                          >
                            {duel.player2Grid.map((row, r) =>
                              row.map((c, idx) => (
                                <div
                                  key={`thumb2-${r}-${idx}`}
                                  style={{ backgroundColor: c && c !== 'transparent' ? c : '#0a0f1d' }}
                                  className="w-full h-full"
                                />
                              ))
                            )}
                          </div>
                        </div>
                        <div className="text-[11px] font-mono text-rose-400 text-center font-bold">
                          Vote to Decide Winner →
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </>
        )}

        {/* TAB 2: COMMUNITY VOTING ARENA */}
        {currentTab === 'voting' && (
          <VotingArena
            duels={votingDuels}
            voterId={player.id}
            onCastVote={handleCastVote}
            selectedDuelId={selectedVotingDuelId}
            onSelectDuel={setSelectedVotingDuelId}
          />
        )}

        {/* TAB 3: ELO LADDER / LEADERBOARD */}
        {currentTab === 'leaderboard' && (
          <LeaderboardView
            players={leaderboard.length > 0 ? leaderboard : [player]}
            currentPlayerId={player.id}
          />
        )}

        {/* TAB 4: LOCAL 2-PLAYER PASS & PLAY */}
        {currentTab === 'local' && <LocalDuelView />}

        {/* TAB 5: FREE DRAW PRACTICE */}
        {currentTab === 'freedraw' && (
          <FreeDrawView onQueueForDuel={handleQueueJoin} />
        )}

        {/* TAB 6: PROFILE & MATCH HISTORY */}
        {currentTab === 'profile' && (
          <ProfileView
            player={player}
            onUpdatePlayer={(upd) => setPlayer((prev) => ({ ...prev, ...upd }))}
            matches={matches}
            onStartDuel={() => { setCurrentTab('arena'); handleQueueJoin(); }}
          />
        )}
      </main>
    </div>
  );
}
