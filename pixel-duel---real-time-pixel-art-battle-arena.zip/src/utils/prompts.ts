export interface PromptItem {
  prompt: string;
  category: 'Creatures' | 'Characters' | 'Items & Food' | 'Cyberpunk' | 'Scenery' | 'Fantasy';
  difficulty: 'Easy' | 'Medium' | 'Hard';
}

export const PROMPT_LIST: PromptItem[] = [
  // Creatures
  { prompt: 'Cyberpunk Cat with Glowing Eyes', category: 'Creatures', difficulty: 'Medium' },
  { prompt: 'Baby Fire Dragon hatchling', category: 'Creatures', difficulty: 'Medium' },
  { prompt: 'Chubby Shiba Inu in Spacesuit', category: 'Creatures', difficulty: 'Medium' },
  { prompt: 'Cute Axolotl with headphones', category: 'Creatures', difficulty: 'Easy' },
  { prompt: 'Ghost Octopus floating in starry void', category: 'Creatures', difficulty: 'Hard' },
  { prompt: 'Steampunk Mechanical Owl', category: 'Creatures', difficulty: 'Hard' },
  { prompt: 'Tiny Frog sitting on a Mushroom', category: 'Creatures', difficulty: 'Easy' },
  { prompt: 'Majestic White Stag with Crystal Antlers', category: 'Creatures', difficulty: 'Hard' },

  // Characters
  { prompt: 'Pixel Ninja slicing through shadows', category: 'Characters', difficulty: 'Medium' },
  { prompt: 'Retro Astronaut drinking Boba Tea', category: 'Characters', difficulty: 'Medium' },
  { prompt: 'Pixel Wizard casting a lightning spark', category: 'Characters', difficulty: 'Medium' },
  { prompt: 'Cyber Samurai with energy katana', category: 'Characters', difficulty: 'Hard' },
  { prompt: 'Little Vampire trying to eat garlic bread', category: 'Characters', difficulty: 'Easy' },
  { prompt: 'Alien DJ jamming at a cosmic synthesizer', category: 'Characters', difficulty: 'Hard' },
  { prompt: 'Tiny Knight wielding giant sword', category: 'Characters', difficulty: 'Easy' },

  // Items & Food
  { prompt: 'Steaming Bowl of Spicy Ramen', category: 'Items & Food', difficulty: 'Medium' },
  { prompt: 'Slice of Pepperoni Pizza with Sunglasses', category: 'Items & Food', difficulty: 'Easy' },
  { prompt: 'Glowing Magic Potion Bottle with Sparkles', category: 'Items & Food', difficulty: 'Easy' },
  { prompt: 'Retro 8-bit Handheld Gaming Console', category: 'Items & Food', difficulty: 'Medium' },
  { prompt: 'Glitchy Golden Crown with Rubies', category: 'Items & Food', difficulty: 'Easy' },
  { prompt: 'Chest bursting with gleaming gems', category: 'Items & Food', difficulty: 'Medium' },
  { prompt: 'Hamburger with floating neon ingredients', category: 'Items & Food', difficulty: 'Medium' },

  // Scenery & Atmosphere
  { prompt: 'Cozy Pixel Campfire under Aurora Borealis', category: 'Scenery', difficulty: 'Medium' },
  { prompt: 'Floating Sky Island with a tiny waterfall', category: 'Scenery', difficulty: 'Hard' },
  { prompt: 'Synthwave Sunset with Neon Palm Trees', category: 'Scenery', difficulty: 'Medium' },
  { prompt: 'Spooky Haunted Castle on a Crag', category: 'Scenery', difficulty: 'Medium' },
  { prompt: 'Tiny Lighthouse in a pixel storm', category: 'Scenery', difficulty: 'Medium' },
  { prompt: 'Cyberpunk Ramen Stand at 3 AM', category: 'Scenery', difficulty: 'Hard' },
];

export function getRandomPrompt(): PromptItem {
  const index = Math.floor(Math.random() * PROMPT_LIST.length);
  return PROMPT_LIST[index];
}
