import { EloTierInfo } from '../types/game';

export const ELO_TIERS: EloTierInfo[] = [
  {
    tier: 'Bronze',
    minElo: 0,
    maxElo: 1099,
    badge: '🥉',
    color: '#cd7f32',
    borderClass: 'border-amber-700/50',
    bgClass: 'bg-amber-950/30 text-amber-400',
    title: 'Pixel Novice',
  },
  {
    tier: 'Silver',
    minElo: 1100,
    maxElo: 1399,
    badge: '🥈',
    color: '#94a3b8',
    borderClass: 'border-slate-400/50',
    bgClass: 'bg-slate-800/40 text-slate-300',
    title: 'Sprite Apprentice',
  },
  {
    tier: 'Gold',
    minElo: 1400,
    maxElo: 1699,
    badge: '🥇',
    color: '#facc15',
    borderClass: 'border-yellow-500/50',
    bgClass: 'bg-yellow-950/30 text-yellow-400',
    title: 'Pixel Artisan',
  },
  {
    tier: 'Platinum',
    minElo: 1700,
    maxElo: 1999,
    badge: '💎',
    color: '#22d3ee',
    borderClass: 'border-cyan-500/50',
    bgClass: 'bg-cyan-950/30 text-cyan-400',
    title: 'Master Colorist',
  },
  {
    tier: 'Diamond',
    minElo: 2000,
    maxElo: 2299,
    badge: '🔮',
    color: '#a855f7',
    borderClass: 'border-purple-500/50',
    bgClass: 'bg-purple-950/30 text-purple-400',
    title: '16-Bit Legend',
  },
  {
    tier: 'Master',
    minElo: 2300,
    maxElo: 2599,
    badge: '⚡',
    color: '#f43f5e',
    borderClass: 'border-rose-500/50',
    bgClass: 'bg-rose-950/30 text-rose-400',
    title: 'Pixel Sovereign',
  },
  {
    tier: 'Grandmaster',
    minElo: 2600,
    maxElo: 9999,
    badge: '👑',
    color: '#fbbf24',
    borderClass: 'border-amber-400',
    bgClass: 'bg-gradient-to-r from-amber-500/20 to-rose-500/20 text-amber-300',
    title: 'Pixel Deity',
  },
];

export function getEloTier(elo: number): EloTierInfo {
  for (let i = ELO_TIERS.length - 1; i >= 0; i--) {
    if (elo >= ELO_TIERS[i].minElo) {
      return ELO_TIERS[i];
    }
  }
  return ELO_TIERS[0];
}

export function getTierProgress(elo: number): { current: number; max: number; percentage: number; nextTier?: EloTierInfo } {
  const currentTier = getEloTier(elo);
  const nextTierIndex = ELO_TIERS.findIndex((t) => t.tier === currentTier.tier) + 1;
  const nextTier = nextTierIndex < ELO_TIERS.length ? ELO_TIERS[nextTierIndex] : undefined;

  if (!nextTier) {
    return { current: elo, max: elo, percentage: 100 };
  }

  const range = nextTier.minElo - currentTier.minElo;
  const earned = Math.max(0, elo - currentTier.minElo);
  const percentage = Math.min(100, Math.round((earned / range) * 100));

  return {
    current: earned,
    max: range,
    percentage,
    nextTier,
  };
}

/**
 * Expected score of Player A vs Player B:
 * Ea = 1 / (1 + 10 ^ ((Rb - Ra) / 400))
 */
export function calculateExpectedScore(ratingA: number, ratingB: number): number {
  return 1 / (1 + Math.pow(10, (ratingB - ratingA) / 400));
}

/**
 * Calculates Elo rating changes based on match outcome
 * K-Factor = 32 standard
 */
export function calculateEloChange(
  ratingA: number,
  ratingB: number,
  scoreA: number, // 1 for win, 0.5 for draw, 0 for loss
  kFactor: number = 32
): { changeA: number; changeB: number; newRatingA: number; newRatingB: number } {
  const expectedA = calculateExpectedScore(ratingA, ratingB);
  const expectedB = 1 - expectedA;
  const scoreB = 1 - scoreA;

  let changeA = Math.round(kFactor * (scoreA - expectedA));
  let changeB = Math.round(kFactor * (scoreB - expectedB));

  // Ensure minimum 1 point movement if won, unless ratings are completely disparate
  if (scoreA === 1 && changeA <= 0) changeA = 1;
  if (scoreB === 1 && changeB <= 0) changeB = 1;

  const newRatingA = Math.max(100, ratingA + changeA);
  const newRatingB = Math.max(100, ratingB + changeB);

  return {
    changeA,
    changeB,
    newRatingA,
    newRatingB,
  };
}
