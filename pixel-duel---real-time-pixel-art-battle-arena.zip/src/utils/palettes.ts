import { Palette, PixelGrid } from '../types/game';

export const RETRO_PALETTES: Palette[] = [
  {
    id: 'pico8',
    name: 'PICO-8 Classic (16 Colors)',
    colors: [
      '#000000', '#1D2B53', '#7E2553', '#008751',
      '#AB5236', '#5F574F', '#C2C3C7', '#FFF1E8',
      '#FF004D', '#FFA300', '#FFEC27', '#00E436',
      '#29ADFF', '#83769C', '#FF77A8', '#FFCCAA'
    ],
  },
  {
    id: 'cyberpunk',
    name: 'Cyberpunk Neon',
    colors: [
      '#09090b', '#18181b', '#3f3f46', '#f43f5e',
      '#fb7185', '#06b6d4', '#22d3ee', '#67e8f9',
      '#8b5cf6', '#a855f7', '#d946ef', '#f472b6',
      '#eab308', '#facc15', '#10b981', '#ffffff'
    ],
  },
  {
    id: 'gameboy',
    name: 'GameBoy DMG-01 (4 Shades)',
    colors: [
      '#0f380f', '#306230', '#8bac0f', '#9bbc0f'
    ],
  },
  {
    id: 'pastel',
    name: 'Kawaii Pastel Dreams',
    colors: [
      '#2b2d42', '#8d99ae', '#edf2f4', '#ffffff',
      '#ffb5a7', '#fcd5ce', '#f8edeb', '#f9dcc4',
      '#fec89a', '#cbf3f0', '#2ec4b6', '#ffbf69',
      '#bde0fe', '#a2d2ff', '#cdb4db', '#ffc8dd'
    ],
  },
  {
    id: 'sunset',
    name: 'Autumn Sunset Glow',
    colors: [
      '#1c0f13', '#391424', '#601a35', '#88223e',
      '#af2b46', '#d63447', '#f57b51', '#f69e6b',
      '#f9c08d', '#fdf3c7', '#7c2d12', '#9a3412',
      '#c2410c', '#ea580c', '#f97316', '#fbbf24'
    ],
  },
];

export function createEmptyGrid(size: number = 16, defaultColor: string = 'transparent'): PixelGrid {
  const grid: PixelGrid = [];
  for (let r = 0; r < size; r++) {
    const row: string[] = [];
    for (let c = 0; c < size; c++) {
      row.push(defaultColor);
    }
    grid.push(row);
  }
  return grid;
}

export function countDrawnPixels(grid: PixelGrid): number {
  let count = 0;
  for (let r = 0; r < grid.length; r++) {
    for (let c = 0; c < grid[r].length; c++) {
      if (grid[r][c] && grid[r][c] !== 'transparent' && grid[r][c] !== 'rgba(0,0,0,0)') {
        count++;
      }
    }
  }
  return count;
}

export function cloneGrid(grid: PixelGrid): PixelGrid {
  return grid.map((row) => [...row]);
}

/**
 * 4-way Flood Fill algorithm for paint bucket
 */
export function floodFill(
  grid: PixelGrid,
  startX: number,
  startY: number,
  targetColor: string,
  fillColor: string
): PixelGrid {
  if (targetColor === fillColor) return grid;
  const newGrid = cloneGrid(grid);
  const sizeY = newGrid.length;
  const sizeX = newGrid[0]?.length || 0;

  if (startX < 0 || startX >= sizeX || startY < 0 || startY >= sizeY) return grid;
  if (newGrid[startY][startX] !== targetColor) return grid;

  const queue: [number, number][] = [[startX, startY]];
  const visited = new Set<string>();

  while (queue.length > 0) {
    const [x, y] = queue.pop()!;
    const key = `${x},${y}`;
    if (visited.has(key)) continue;
    visited.add(key);

    if (x < 0 || x >= sizeX || y < 0 || y >= sizeY) continue;
    if (newGrid[y][x] !== targetColor) continue;

    newGrid[y][x] = fillColor;

    queue.push([x + 1, y]);
    queue.push([x - 1, y]);
    queue.push([x, y + 1]);
    queue.push([x, y - 1]);
  }

  return newGrid;
}

/**
 * Bresenham's line algorithm for straight pixel lines
 */
export function drawLine(
  grid: PixelGrid,
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  color: string
): PixelGrid {
  const newGrid = cloneGrid(grid);
  const dx = Math.abs(x1 - x0);
  const dy = Math.abs(y1 - y0);
  const sx = x0 < x1 ? 1 : -1;
  const sy = y0 < y1 ? 1 : -1;
  let err = dx - dy;

  let curX = x0;
  let curY = y0;

  while (true) {
    if (curY >= 0 && curY < newGrid.length && curX >= 0 && curX < newGrid[0].length) {
      newGrid[curY][curX] = color;
    }
    if (curX === x1 && curY === y1) break;
    const e2 = 2 * err;
    if (e2 > -dy) {
      err -= dy;
      curX += sx;
    }
    if (e2 < dx) {
      err += dx;
      curY += sy;
    }
  }

  return newGrid;
}

/**
 * Draw rectangle (outline or filled)
 */
export function drawRect(
  grid: PixelGrid,
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  color: string,
  filled: boolean = false
): PixelGrid {
  const newGrid = cloneGrid(grid);
  const minX = Math.min(x0, x1);
  const maxX = Math.max(x0, x1);
  const minY = Math.min(y0, y1);
  const maxY = Math.max(y0, y1);

  for (let y = minY; y <= maxY; y++) {
    for (let x = minX; x <= maxX; x++) {
      if (y >= 0 && y < newGrid.length && x >= 0 && x < newGrid[0].length) {
        if (filled || x === minX || x === maxX || y === minY || y === maxY) {
          newGrid[y][x] = color;
        }
      }
    }
  }

  return newGrid;
}

/**
 * Exports pixel grid to high-res PNG Blob/DataURL
 */
export function exportGridToDataUrl(grid: PixelGrid, scale: number = 20): string {
  const canvas = document.createElement('canvas');
  const height = grid.length;
  const width = grid[0]?.length || 0;
  canvas.width = width * scale;
  canvas.height = height * scale;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  ctx.imageSmoothingEnabled = false;

  for (let r = 0; r < height; r++) {
    for (let c = 0; c < width; c++) {
      const color = grid[r][c];
      if (color && color !== 'transparent') {
        ctx.fillStyle = color;
        ctx.fillRect(c * scale, r * scale, scale, scale);
      }
    }
  }

  return canvas.toDataURL('image/png');
}
