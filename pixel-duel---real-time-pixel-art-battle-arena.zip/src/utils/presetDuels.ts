import { DuelRoom, HistoricalMatch, PixelGrid } from '../types/game';
import { createEmptyGrid } from './palettes';

// Helper to render pixel art from compact ASCII string map
export function asciiToGrid(ascii: string[], colorMap: Record<string, string>, size: number = 16): PixelGrid {
  const grid = createEmptyGrid(size);
  for (let r = 0; r < Math.min(ascii.length, size); r++) {
    const line = ascii[r];
    for (let c = 0; c < Math.min(line.length, size); c++) {
      const char = line[c];
      if (colorMap[char]) {
        grid[r][c] = colorMap[char];
      }
    }
  }
  return grid;
}

// 1. Ghost Art A & B (Prompt: "Cute Ghost with Headphones")
const ghostA = asciiToGrid([
  "......####......",
  "....#H....H#....",
  "...#H.WWWW.H#...",
  "..#..W....W..#..",
  "..#..W.B.B.W..#.",
  ".....W.B.B.W....",
  ".....WWWWWWW....",
  ".....W.....W....",
  ".....W.PPP.W....",
  ".....WWWWWWW....",
  ".....W.....W....",
  ".....WW.W.WW....",
  "......W.W.W.....",
  "................",
  "................",
  "................",
], {
  '#': '#ec4899', // pink headphones band
  'H': '#f43f5e', // ear cups
  'W': '#ffffff', // ghost body
  'B': '#0f172a', // eyes
  'P': '#fb7185', // blush
  '.': 'transparent'
});

const ghostB = asciiToGrid([
  "....######......",
  "...#......#.....",
  "..#..WWWW..#....",
  "..#.W....W.#....",
  "..C.W.OO.W.C....",
  "..C.W.OO.W.C....",
  "....W....W......",
  "....W.VV.W......",
  "....WWWWWW......",
  "....W....W......",
  "....WWWWWW......",
  "....W.WW.W......",
  "....W....W......",
  "....WW..WW......",
  "................",
  "................",
], {
  '#': '#06b6d4', // cyan headphones
  'C': '#22d3ee', // cyan ear pads
  'W': '#f8fafc', // white ghost
  'O': '#6366f1', // glowing indigo eyes
  'V': '#f43f5e', // smile
  '.': 'transparent'
});

// 2. Pizza Art A & B (Prompt: "Slice of Pepperoni Pizza with Sunglasses")
const pizzaA = asciiToGrid([
  "....CCCCCCCC....",
  "....CCCCCCCC....",
  ".....YYYYYY.....",
  "....YBB..BBY....",
  "....YBB..BBY....",
  "....YBBBBBY.....",
  ".....Y.RR.Y.....",
  ".....Y.RR.Y.....",
  "......Y..Y......",
  "......Y..Y......",
  "......Y.RR......",
  ".......YRY......",
  ".......YY.......",
  "........Y.......",
  "................",
  "................",
], {
  'C': '#d97706', // crust
  'Y': '#facc15', // melted cheese
  'B': '#18181b', // sunglasses
  'R': '#dc2626', // pepperoni
  '.': 'transparent'
});

const pizzaB = asciiToGrid([
  "...KKKKKKKKK....",
  "....YYYYYYY.....",
  "...Y.GG..GG.Y...",
  "...Y.GG..GG.Y...",
  "....YGGGGGGY....",
  "....Y.RR..RY....",
  ".....YRR..RY....",
  ".....Y....Y.....",
  "......Y.MMY.....",
  "......Y.MMY.....",
  ".......Y.Y......",
  ".......Y.Y......",
  "........Y.......",
  "................",
  "................",
  "................",
], {
  'K': '#b45309', // crust
  'Y': '#fbbf24', // cheese
  'G': '#1e293b', // cool shades
  'R': '#ef4444', // pepperoni
  'M': '#15803d', // mushroom/basil
  '.': 'transparent'
});

// 3. Cyberpunk Cat A & B (Prompt: "Cyberpunk Cat with Glowing Eyes")
const catA = asciiToGrid([
  "...#......#.....",
  "...##....##.....",
  "..#..#..#..#....",
  "..#...##...#....",
  "..#..GG..GG#....",
  "..#..GG..GG#....",
  "..#...PP...#....",
  "..#..P..P..#....",
  "...########.....",
  "....#CCCC#......",
  "....#....#......",
  "...##....##.....",
  "..#.#....#.#....",
  "..#.#....#.#....",
  "................",
  "................",
], {
  '#': '#312e81', // dark cyber fur
  'G': '#22d3ee', // neon cyan eyes
  'P': '#f43f5e', // neon nose/mouth
  'C': '#a855f7', // collar
  '.': 'transparent'
});

const catB = asciiToGrid([
  "..#........#....",
  "..##......##....",
  "..###....###....",
  ".#...####...#...",
  ".#..YY..YY..#...",
  ".#..YY..YY..#...",
  ".#....TT....#...",
  ".#...T..T...#...",
  "..##########....",
  "...#......#.....",
  "...#..RR..#.....",
  "..#........#....",
  ".##........##...",
  "................",
  "................",
  "................",
], {
  '#': '#18181b', // sleek panther black
  'Y': '#eab308', // glowing golden visor
  'T': '#ec4899', // pink whiskers
  'R': '#06b6d4', // neon chest emblem
  '.': 'transparent'
});

// 4. Magic Potion A & B (Prompt: "Glowing Magic Potion Bottle with Sparkles")
const potionA = asciiToGrid([
  ".......CC.......",
  ".......CC.......",
  "......GGGG......",
  "......G..G......",
  ".....G....G.....",
  "....G..PP..G....",
  "...G..PPPP..G...",
  "...G.PPPPPP.G...",
  "...G.PPWWPP.G...",
  "...G.PPPPPP.G...",
  "...G..PPPP..G...",
  "....G......G....",
  ".....GGGGGG.....",
  "................",
  "................",
  "................",
], {
  'C': '#78350f', // cork
  'G': '#67e8f9', // glass reflection
  'P': '#a855f7', // magic purple liquid
  'W': '#ffffff', // sparkle
  '.': 'transparent'
});

const potionB = asciiToGrid([
  "......XXXX......",
  ".......KK.......",
  ".......KK.......",
  "......G..G......",
  "....GG....GG....",
  "...G...EE...G...",
  "..G...EEEE...G..",
  "..G..EEFFEE..G..",
  "..G..EEEEEE..G..",
  "..G...EEEE...G..",
  "...GG......GG...",
  ".....GGGGGG.....",
  "................",
  "................",
  "................",
  "................",
], {
  'X': '#92400e', // stopper
  'K': '#cbd5e1', // neck
  'G': '#94a3b8', // bottle
  'E': '#10b981', // emerald elixir
  'F': '#ecfdf5', // shine
  '.': 'transparent'
});

export const PRESET_VOTING_DUELS: DuelRoom[] = [
  {
    id: 'duel-seed-101',
    prompt: 'Cute Ghost with Headphones',
    category: 'Creatures',
    gridSize: 16,
    durationSeconds: 60,
    timeRemaining: 0,
    phase: 'voting',
    createdAt: Date.now() - 1000 * 45,
    player1: {
      id: 'p-valkyrie',
      name: 'PixelValkyrie',
      avatar: '👑',
      elo: 1620,
      matchesPlayed: 74,
      wins: 48,
      losses: 22,
      draws: 4,
      currentStreak: 3,
      bestStreak: 8,
    },
    player2: {
      id: 'p-chiptune',
      name: 'ChiptuneHero',
      avatar: '🎧',
      elo: 1585,
      matchesPlayed: 62,
      wins: 38,
      losses: 21,
      draws: 3,
      currentStreak: 1,
      bestStreak: 6,
    },
    player1Grid: ghostA,
    player2Grid: ghostB,
    player1PixelCount: 68,
    player2PixelCount: 62,
    player1Votes: 14,
    player2Votes: 11,
    votedUserIds: [],
    winnerId: undefined,
  },
  {
    id: 'duel-seed-102',
    prompt: 'Slice of Pepperoni Pizza with Sunglasses',
    category: 'Items & Food',
    gridSize: 16,
    durationSeconds: 60,
    timeRemaining: 0,
    phase: 'voting',
    createdAt: Date.now() - 1000 * 95,
    player1: {
      id: 'p-neon',
      name: 'NeonSprite',
      avatar: '⚡',
      elo: 1490,
      matchesPlayed: 45,
      wins: 29,
      losses: 14,
      draws: 2,
      currentStreak: 2,
      bestStreak: 5,
    },
    player2: {
      id: 'p-vandals',
      name: '8BitVandals',
      avatar: '👾',
      elo: 1520,
      matchesPlayed: 88,
      wins: 54,
      losses: 30,
      draws: 4,
      currentStreak: 0,
      bestStreak: 7,
    },
    player1Grid: pizzaA,
    player2Grid: pizzaB,
    player1PixelCount: 54,
    player2PixelCount: 58,
    player1Votes: 23,
    player2Votes: 19,
    votedUserIds: [],
    winnerId: undefined,
  },
  {
    id: 'duel-seed-103',
    prompt: 'Cyberpunk Cat with Glowing Eyes',
    category: 'Cyberpunk',
    gridSize: 16,
    durationSeconds: 60,
    timeRemaining: 0,
    phase: 'voting',
    createdAt: Date.now() - 1000 * 150,
    player1: {
      id: 'p-ghost',
      name: 'GhostPainter',
      avatar: '👻',
      elo: 1780,
      matchesPlayed: 112,
      wins: 82,
      losses: 25,
      draws: 5,
      currentStreak: 5,
      bestStreak: 12,
    },
    player2: {
      id: 'p-retromaster',
      name: 'RetroMaster_99',
      avatar: '🕹️',
      elo: 1740,
      matchesPlayed: 96,
      wins: 65,
      losses: 27,
      draws: 4,
      currentStreak: 2,
      bestStreak: 9,
    },
    player1Grid: catA,
    player2Grid: catB,
    player1PixelCount: 72,
    player2PixelCount: 76,
    player1Votes: 35,
    player2Votes: 31,
    votedUserIds: [],
    winnerId: undefined,
  },
  {
    id: 'duel-seed-104',
    prompt: 'Glowing Magic Potion Bottle with Sparkles',
    category: 'Fantasy',
    gridSize: 16,
    durationSeconds: 60,
    timeRemaining: 0,
    phase: 'voting',
    createdAt: Date.now() - 1000 * 220,
    player1: {
      id: 'p-starlight',
      name: 'StarlightPixel',
      avatar: '✨',
      elo: 1395,
      matchesPlayed: 32,
      wins: 19,
      losses: 12,
      draws: 1,
      currentStreak: 1,
      bestStreak: 4,
    },
    player2: {
      id: 'p-alchemist',
      name: 'PixelAlchemist',
      avatar: '🧪',
      elo: 1410,
      matchesPlayed: 51,
      wins: 30,
      losses: 18,
      draws: 3,
      currentStreak: 3,
      bestStreak: 6,
    },
    player1Grid: potionA,
    player2Grid: potionB,
    player1PixelCount: 64,
    player2PixelCount: 60,
    player1Votes: 18,
    player2Votes: 21,
    votedUserIds: [],
    winnerId: undefined,
  }
];

export const PRESET_HISTORICAL_MATCHES: HistoricalMatch[] = [
  {
    id: 'hist-1',
    date: 'Today, 2:15 PM',
    prompt: 'Cute Ghost with Headphones',
    opponentName: 'ChiptuneHero',
    opponentElo: 1585,
    result: 'win',
    eloChange: 18,
    myGrid: ghostA,
    opponentGrid: ghostB,
    myVotes: 28,
    opponentVotes: 19,
  },
  {
    id: 'hist-2',
    date: 'Yesterday, 8:40 PM',
    prompt: 'Slice of Pepperoni Pizza with Sunglasses',
    opponentName: '8BitVandals',
    opponentElo: 1520,
    result: 'win',
    eloChange: 16,
    myGrid: pizzaA,
    opponentGrid: pizzaB,
    myVotes: 34,
    opponentVotes: 22,
  },
  {
    id: 'hist-3',
    date: '2 days ago',
    prompt: 'Glowing Magic Potion Bottle with Sparkles',
    opponentName: 'PixelAlchemist',
    opponentElo: 1410,
    result: 'loss',
    eloChange: -15,
    myGrid: potionA,
    opponentGrid: potionB,
    myVotes: 18,
    opponentVotes: 27,
  }
];
